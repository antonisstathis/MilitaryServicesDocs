INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES
(false, false, 1, 'Stelios', 'Alexopoulos', 'active', 'Omirou 13', 'Kavala', '1', 'Ioanna', '6991797236', 'Alexandros', 'armed', 'A', 'SBQ5536'),

(false, false, 1, 'Petros', 'Georgiou', 'active', 'Solonos 12', 'Komotini', '1', 'Ioanna', '6929087474', 'Petros', 'armed', 'A', 'MDI1648'),

(false, false, 1, 'Sotiris', 'Petridis', 'active', 'Omirou 84', 'Kavala', '1', 'Eirini', '6950600373', 'Alexandros', 'armed', 'A', 'FEX1758'),

(false, false, 1, 'Kostas', 'Alexopoulos', 'active', 'Sokratous 69', 'Volos', '1', 'Sofia', '6911160867', 'Manolis', 'armed', 'A', 'WMS9649'),

(false, false, 1, 'Giorgos', 'Theodorakis', 'active', 'Omirou 150', 'Larisa', '1', 'Dimitra', '6912793423', 'Stelios', 'armed', 'A', 'PQJ1829'),

(false, false, 1, 'Michalis', 'Georgiou', 'active', 'Venizelou 91', 'Heraklion', '1', 'Maria', '6941146963', 'Petros', 'armed', 'A', 'MTC8060'),

(false, false, 1, 'Nikos', 'Georgiou', 'active', 'Papandreou 15', 'Komotini', '1', 'Dimitra', '6996308956', 'Michail', 'unarmed', 'A', 'VWA4128'),

(false, false, 1, 'Leonidas', 'Alexopoulos', 'active', 'Vempo Sophias 146', 'Athens', '1', 'Dimitra', '6938407980', 'Christos', 'armed', 'A', 'SLP0351'),

(false, false, 1, 'Thanasis', 'Karalis', 'active', 'Platonos 169', 'Volos', '1', 'Dimitra', '6937602668', 'Georgios', 'armed', 'A', 'YVB4867'),

(false, false, 1, 'Thanasis', 'Ioannou', 'active', 'Solonos 152', 'Larisa', '1', 'Ioanna', '6908234268', 'Stelios', 'unarmed', 'A', 'YAU8509');


INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES
(false, 1, 'armed',   'Perimeter patrol',      'A', 'SERV1', ''),
(false, 1, 'armed',   'Guard post shift A',    'A', 'SERV2', ''),
(false, 1, 'armed',   'Gate monitoring',       'A', 'SERV3', ''),
(false, 1, 'armed',   'Guard post shift A',    'A', 'SERV4', ''),
(false, 1, 'armed',   'Perimeter patrol',      'A', 'SERV5', ''),
(false, 1, 'armed',   'Night watch',           'A', 'SERV6', ''),
(false, 1, 'armed',   'Perimeter patrol',      'A', 'SERV7', ''),
(false, 1, 'unarmed', 'Vehicle checkpoint',    'A', 'SERV8', ''),
(false, 1, 'unarmed', 'Gate monitoring',       'A', 'SERV9', ''),
(false, 1, 'unarmed', 'Night watch',           'A', 'SERV10', '');
