INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES
(false, false, 1, 'Kostas', 'Karalis', 'active', 'Perikleous 131', 'Komotini', '1',
 'Katerina', '6936053562', 'Michail', 'armed', 'A', 'OUD8919'),

(false, false, 1, 'Thanasis', 'Karalis', 'active', 'Vempo Sophias 106', 'Serres', '1',
 'Eirini', '6962967559', 'Georgios', 'armed', 'A', 'NQR2329'),

(false, false, 1, 'Alexandros', 'Ioannou', 'active', 'Papandreou 147', 'Athens', '1',
 'Maria', '6900680334', 'Ioannis', 'unarmed', 'A', 'JGB5746'),

(false, false, 1, 'Michalis', 'Mantzouranis', 'active', 'Karaiskaki 197', 'Larisa', '1',
 'Anna', '6904288330', 'Pavlos', 'armed', 'A', 'RRU3256'),

(false, false, 1, 'Thanasis', 'Zafeiris', 'active', 'Papandreou 129', 'Larisa', '1',
 'Eirini', '6932607180', 'Stelios', 'armed', 'A', 'TTH5876'),

(false, false, 1, 'Michalis', 'Mantzouranis', 'active', 'Sokratous 159', 'Thessaloniki', '1',
 'Maria', '6988074780', 'Stelios', 'unarmed', 'A', 'CJF4371'),

(false, false, 1, 'Nikos', 'Panagiotou', 'active', 'Venizelou 111', 'Thessaloniki', '1',
 'Eleni', '6928863160', 'Ioannis', 'armed', 'A', 'JEI4978'),

(false, false, 1, 'Vasilis', 'Papadopoulos', 'active', 'Sokratous 56', 'Serres', '1',
 'Georgia', '6931303898', 'Alexandros', 'armed', 'A', 'WJX2729'),

(false, false, 1, 'Kostas', 'Georgiou', 'active', 'Perikleous 185', 'Heraklion', '1',
 'Ioanna', '6938527399', 'Manolis', 'armed', 'A', 'OOL2623'),

(false, false, 1, 'Pavlos', 'Kotsis', 'active', 'Venizelou 30', 'Serres', '1',
 'Dimitra', '6981684582', 'Sotirios', 'armed', 'A', 'ZFF6287'),

(false, false, 1, 'Giorgos', 'Athanasiadis', 'active', 'Sokratous 123', 'Athens', '1',
 'Maria', '6987704984', 'Anastasios', 'unarmed', 'A', 'BXB1544'),

(false, false, 1, 'Leonidas', 'Petridis', 'active', 'Venizelou 124', 'Kavala', '1',
 'Ioanna', '6946767582', 'Thanasis', 'armed', 'A', 'VVW8001'),

(false, false, 1, 'Petros', 'Papadopoulos', 'active', 'Sokratous 123', 'Komotini', '1',
 'Katerina', '6988203394', 'Michail', 'unarmed', 'A', 'GXU8535'),

(false, false, 1, 'Giannis', 'Kotsis', 'active', 'Venizelou 198', 'Patra', '1',
 'Anna', '6925592638', 'Stelios', 'armed', 'A', 'NMP9066'),

(false, false, 1, 'Pavlos', 'Petridis', 'active', 'Omirou 126', 'Heraklion', '1',
 'Anna', '6933799534', 'Konstantinos', 'armed', 'A', 'MGA9321'),

(false, false, 1, 'Giorgos', 'Lazaridis', 'active', 'Sokratous 13', 'Chania', '1',
 'Eirini', '6920437525', 'Manolis', 'unarmed', 'A', 'JXQ9659'),

(false, false, 1, 'Sotiris', 'Papadopoulos', 'active', 'Papandreou 176', 'Athens', '1',
 'Eleni', '6990940039', 'Ioannis', 'armed', 'A', 'HGA9038'),

(false, false, 1, 'Theodoros', 'Christou', 'active', 'Sokratous 32', 'Kavala', '1',
 'Maria', '6997309938', 'Anastasios', 'armed', 'A', 'XNC9720'),

(false, false, 1, 'Michalis', 'Dedes', 'active', 'Sokratous 89', 'Heraklion', '1',
 'Anna', '6939148594', 'Michail', 'unarmed', 'A', 'RDR5639'),

(false, false, 1, 'Petros', 'Zafeiris', 'active', 'Sokratous 6', 'Patra', '1',
 'Eleni', '6904720458', 'Michail', 'armed', 'A', 'SYR9418'),

(false, false, 1, 'Christos', 'Spanos', 'active', 'Karaiskaki 3', 'Heraklion', '1',
 'Maria', '6940379205', 'Leonidas', 'armed', 'A', 'WAJ4455'),

(false, false, 1, 'Christos', 'Theodorakis', 'active', 'Sokratous 80', 'Chania', '1',
 'Katerina', '6998255722', 'Alexandros', 'armed', 'A', 'AAU7843'),

(false, false, 1, 'Thanasis', 'Panagiotou', 'active', 'Omirou 90', 'Komotini', '1',
 'Maria', '6935885807', 'Stelios', 'unarmed', 'A', 'VSK7553'),

(false, false, 1, 'Theodoros', 'Kotsis', 'active', 'Platonos 173', 'Volos', '1',
 'Eleni', '6929273730', 'Ioannis', 'unarmed', 'A', 'SAM1023');


INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES
(false, 1, 'armed',   'Guard post shift B',           'A', 'SERV1', ''),
(false, 1, 'armed',   'Gate monitoring',              'A', 'SERV2', ''),
(false, 1, 'armed',   'Communication room duty',      'A', 'SERV3', ''),
(false, 1, 'armed',   'Perimeter patrol',             'A', 'SERV4', ''),
(false, 1, 'armed',   'Guard post shift B',           'A', 'SERV5', ''),
(false, 1, 'armed',   'Night watch',                  'A', 'SERV6', ''),
(false, 1, 'armed',   'Perimeter patrol',             'A', 'SERV7', ''),
(false, 1, 'armed',   'Night watch',                  'A', 'SERV8', ''),
(false, 1, 'unarmed', 'Communication room duty',      'A', 'SERV9', ''),
(false, 1, 'unarmed', 'Equipment room duty',          'A', 'SERV10', ''),
(false, 1, 'unarmed', 'Communication room duty',      'A', 'SERV11', ''),
(false, 1, 'unarmed', 'Guard post shift A',            'A', 'SERV12', '');
