
SET search_path TO ms;

INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Karalis', 'active',
 'Platonos 186', 'Athens', '1',
 'Vasiliki', '6932860008', 'Pavlos',
 'armed', 'A', 'LMU3527');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Alexopoulos', 'active',
 'Venizelou 46', 'Athens', '1',
 'Anna', '6965269349', 'Christos',
 'armed', 'A', 'OWE2785');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Lazaridis', 'active',
 'Omirou 152', 'Volos', '1',
 'Dimitra', '6922617361', 'Anastasios',
 'unarmed', 'A', 'RUY1833');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Panagiotou', 'active',
 'Karaiskaki 143', 'Athens', '1',
 'Maria', '6978872194', 'Leonidas',
 'armed', 'A', 'VUT3026');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Zafeiris', 'active',
 'Venizelou 81', 'Patra', '1',
 'Eirini', '6970603522', 'Vasileios',
 'armed', 'A', 'MFE9948');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Lazaridis', 'active',
 'Vempo Sophias 81', 'Larisa', '1',
 'Maria', '6967399671', 'Georgios',
 'armed', 'A', 'CRQ0512');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Alexopoulos', 'active',
 'Solonos 128', 'Athens', '1',
 'Anna', '6992883334', 'Michail',
 'armed', 'A', 'NPO5721');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Mantzouranis', 'active',
 'Omirou 27', 'Komotini', '1',
 'Sofia', '6973603609', 'Manolis',
 'armed', 'A', 'KCF7932');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Platonos 104', 'Komotini', '1',
 'Sofia', '6932342448', 'Christos',
 'armed', 'A', 'SQT9130');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Vempo Sophias 143', 'Larisa', '1',
 'Sofia', '6949615385', 'Stelios',
 'armed', 'A', 'UVW8953');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Theodorakis', 'active',
 'Platonos 44', 'Heraklion', '1',
 'Ioanna', '6918137339', 'Leonidas',
 'armed', 'A', 'ARY2448');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Georgiou', 'active',
 'Sokratous 41', 'Komotini', '1',
 'Eirini', '6990173991', 'Sotirios',
 'armed', 'A', 'QDW9565');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Spanos', 'active',
 'Perikleous 28', 'Komotini', '1',
 'Maria', '6910039981', 'Sotirios',
 'unarmed', 'A', 'JJW2441');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Mantzouranis', 'active',
 'Solonos 85', 'Serres', '1',
 'Maria', '6941105141', 'Manolis',
 'armed', 'A', 'EOD2446');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Lazaridis', 'active',
 'Perikleous 33', 'Thessaloniki', '1',
 'Anna', '6966767246', 'Stelios',
 'armed', 'A', 'KXB4176');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Venizelou 183', 'Chania', '1',
 'Ioanna', '6931824614', 'Leonidas',
 'armed', 'A', 'CMF6966');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Georgiou', 'active',
 'Vempo Sophias 97', 'Larisa', '1',
 'Georgia', '6963072787', 'Leonidas',
 'unarmed', 'A', 'UHC4085');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Papadopoulos', 'active',
 'Solonos 32', 'Serres', '1',
 'Ioanna', '6964442445', 'Thanasis',
 'armed', 'A', 'EDN5551');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Lazaridis', 'active',
 'Solonos 52', 'Chania', '1',
 'Dimitra', '6955566266', 'Christos',
 'armed', 'A', 'CBX5703');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Lazaridis', 'active',
 'Papandreou 199', 'Serres', '1',
 'Anna', '6954989884', 'Leonidas',
 'armed', 'A', 'JEJ6606');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Zafeiris', 'active',
 'Platonos 184', 'Larisa', '1',
 'Eleni', '6964448992', 'Sotirios',
 'armed', 'A', 'SWF3363');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Zafeiris', 'active',
 'Sokratous 135', 'Volos', '1',
 'Anna', '6941129425', 'Christos',
 'armed', 'A', 'FJA3511');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Theodorakis', 'active',
 'Omirou 113', 'Athens', '1',
 'Eleni', '6923890719', 'Thanasis',
 'armed', 'A', 'TOZ3031');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Zafeiris', 'active',
 'Karaiskaki 18', 'Heraklion', '1',
 'Dimitra', '6909811569', 'Leonidas',
 'armed', 'A', 'WXX7835');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Athanasiadis', 'active',
 'Papandreou 113', 'Patra', '1',
 'Vasiliki', '6941432604', 'Michail',
 'armed', 'A', 'NXP4505');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Georgiou', 'active',
 'Venizelou 56', 'Komotini', '1',
 'Eirini', '6900789992', 'Thanasis',
 'unarmed', 'A', 'NPV9889');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Karalis', 'active',
 'Omirou 109', 'Thessaloniki', '1',
 'Maria', '6934650942', 'Konstantinos',
 'armed', 'A', 'PVH8274');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Christou', 'active',
 'Papandreou 86', 'Patra', '1',
 'Katerina', '6900340040', 'Vasileios',
 'armed', 'A', 'CEA5502');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Athanasiadis', 'active',
 'Karaiskaki 3', 'Larisa', '1',
 'Vasiliki', '6962328207', 'Sotirios',
 'armed', 'A', 'JLP6634');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Zafeiris', 'active',
 'Omirou 147', 'Volos', '1',
 'Eirini', '6943379039', 'Michail',
 'armed', 'A', 'CSL3482');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Athanasiadis', 'active',
 'Vempo Sophias 195', 'Patra', '1',
 'Ioanna', '6966381240', 'Leonidas',
 'armed', 'A', 'MKQ3900');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Kotsis', 'active',
 'Papandreou 134', 'Athens', '1',
 'Eleni', '6907485546', 'Konstantinos',
 'armed', 'A', 'LUS9393');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Venizelou 47', 'Kavala', '1',
 'Dimitra', '6940005152', 'Pavlos',
 'armed', 'A', 'FPT5891');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Papandreou 65', 'Kavala', '1',
 'Eleni', '6909989945', 'Sotirios',
 'armed', 'A', 'DSI3939');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Dedes', 'active',
 'Perikleous 30', 'Serres', '1',
 'Eirini', '6962976002', 'Petros',
 'unarmed', 'A', 'TYD4399');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Petridis', 'active',
 'Platonos 124', 'Komotini', '1',
 'Dimitra', '6921202041', 'Georgios',
 'unarmed', 'A', 'ZJX8074');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Omirou 176', 'Larisa', '1',
 'Vasiliki', '6918976426', 'Alexandros',
 'armed', 'A', 'NHJ5749');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Athanasiadis', 'active',
 'Venizelou 132', 'Heraklion', '1',
 'Sofia', '6964893887', 'Theodoros',
 'armed', 'A', 'QXW8083');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Athanasiadis', 'active',
 'Omirou 95', 'Serres', '1',
 'Eirini', '6989590443', 'Petros',
 'armed', 'A', 'QIR3669');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Nikolaidis', 'active',
 'Karaiskaki 103', 'Larisa', '1',
 'Katerina', '6903922092', 'Alexandros',
 'armed', 'A', 'NBH0026');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Spanos', 'active',
 'Solonos 24', 'Heraklion', '1',
 'Georgia', '6964368721', 'Vasileios',
 'armed', 'A', 'RKT5876');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Athanasiadis', 'active',
 'Platonos 44', 'Chania', '1',
 'Sofia', '6915603704', 'Konstantinos',
 'unarmed', 'A', 'YKQ6685');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Papandreou 180', 'Komotini', '1',
 'Eirini', '6933856496', 'Theodoros',
 'armed', 'A', 'MPC6042');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Mantzouranis', 'active',
 'Solonos 36', 'Larisa', '1',
 'Vasiliki', '6949741926', 'Vasileios',
 'armed', 'A', 'ILG6430');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Platonos 144', 'Patra', '1',
 'Sofia', '6955224481', 'Georgios',
 'armed', 'A', 'YMS3858');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Dedes', 'active',
 'Omirou 106', 'Kavala', '1',
 'Georgia', '6961303782', 'Theodoros',
 'armed', 'A', 'TPM6913');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Spanos', 'active',
 'Venizelou 83', 'Komotini', '1',
 'Ioanna', '6933321068', 'Alexandros',
 'armed', 'A', 'XAQ9403');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Georgiou', 'active',
 'Vempo Sophias 26', 'Serres', '1',
 'Georgia', '6919100105', 'Theodoros',
 'armed', 'A', 'IZG7417');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Nikolaidis', 'active',
 'Venizelou 48', 'Chania', '1',
 'Katerina', '6943685891', 'Anastasios',
 'armed', 'A', 'ZTL7755');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Panagiotou', 'active',
 'Perikleous 41', 'Patra', '1',
 'Georgia', '6979076724', 'Georgios',
 'armed', 'A', 'UMR6592');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Ioannou', 'active',
 'Perikleous 1', 'Patra', '1',
 'Dimitra', '6956184250', 'Theodoros',
 'armed', 'A', 'ETO6516');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Papadopoulos', 'active',
 'Venizelou 86', 'Thessaloniki', '1',
 'Katerina', '6922555646', 'Stelios',
 'armed', 'A', 'ZGS8232');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Spanos', 'active',
 'Vempo Sophias 107', 'Serres', '1',
 'Sofia', '6942573962', 'Thanasis',
 'armed', 'A', 'ECX3996');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Omirou 194', 'Chania', '1',
 'Anna', '6952405932', 'Petros',
 'armed', 'A', 'HDX7881');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Venizelou 70', 'Patra', '1',
 'Eleni', '6920321780', 'Georgios',
 'armed', 'A', 'TMD1442');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Venizelou 32', 'Chania', '1',
 'Sofia', '6928153723', 'Vasileios',
 'armed', 'A', 'MZC6450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Kotsis', 'active',
 'Omirou 99', 'Athens', '1',
 'Anna', '6985136551', 'Theodoros',
 'armed', 'A', 'RZD3096');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Papadopoulos', 'active',
 'Vempo Sophias 143', 'Komotini', '1',
 'Eirini', '6941744929', 'Anastasios',
 'armed', 'A', 'OEX4842');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Athanasiadis', 'active',
 'Karaiskaki 42', 'Athens', '1',
 'Georgia', '6954646831', 'Michail',
 'armed', 'A', 'HFP5300');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Alexopoulos', 'active',
 'Omirou 27', 'Chania', '1',
 'Eirini', '6941232114', 'Manolis',
 'armed', 'A', 'KZY1425');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Zafeiris', 'active',
 'Omirou 103', 'Serres', '1',
 'Vasiliki', '6908094533', 'Thanasis',
 'armed', 'A', 'WRX2204');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Athanasiadis', 'active',
 'Perikleous 37', 'Thessaloniki', '1',
 'Sofia', '6930535875', 'Thanasis',
 'armed', 'A', 'PEY7243');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Zafeiris', 'active',
 'Sokratous 144', 'Patra', '1',
 'Eleni', '6938910495', 'Anastasios',
 'armed', 'A', 'YJJ7133');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Karalis', 'active',
 'Papandreou 169', 'Volos', '1',
 'Dimitra', '6916988786', 'Petros',
 'armed', 'A', 'ATI8239');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Platonos 48', 'Chania', '1',
 'Vasiliki', '6934234198', 'Petros',
 'armed', 'A', 'OJS9807');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Mantzouranis', 'active',
 'Solonos 65', 'Larisa', '1',
 'Vasiliki', '6948756551', 'Stelios',
 'armed', 'A', 'LMS5853');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Petridis', 'active',
 'Papandreou 118', 'Larisa', '1',
 'Dimitra', '6934108370', 'Christos',
 'armed', 'A', 'FMM2214');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Panagiotou', 'active',
 'Omirou 130', 'Komotini', '1',
 'Vasiliki', '6955641101', 'Theodoros',
 'armed', 'A', 'ETE1809');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Mantzouranis', 'active',
 'Perikleous 27', 'Komotini', '1',
 'Eirini', '6902067401', 'Alexandros',
 'armed', 'A', 'TIL7330');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Kotsis', 'active',
 'Sokratous 114', 'Chania', '1',
 'Eleni', '6926485016', 'Christos',
 'unarmed', 'A', 'KUW4102');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Karalis', 'active',
 'Karaiskaki 139', 'Heraklion', '1',
 'Katerina', '6932958735', 'Sotirios',
 'armed', 'A', 'XHH1100');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Omirou 189', 'Komotini', '1',
 'Eirini', '6948923948', 'Alexandros',
 'armed', 'A', 'SNS2230');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Lazaridis', 'active',
 'Vempo Sophias 161', 'Patra', '1',
 'Ioanna', '6973745724', 'Georgios',
 'armed', 'A', 'AAR8170');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Solonos 150', 'Heraklion', '1',
 'Eirini', '6991188842', 'Leonidas',
 'armed', 'A', 'DXQ0352');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Christou', 'active',
 'Sokratous 85', 'Volos', '1',
 'Dimitra', '6958103638', 'Christos',
 'armed', 'A', 'CGL4640');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Athanasiadis', 'active',
 'Sokratous 115', 'Athens', '1',
 'Dimitra', '6939932931', 'Konstantinos',
 'armed', 'A', 'LCW0538');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Mantzouranis', 'active',
 'Sokratous 155', 'Serres', '1',
 'Sofia', '6923449883', 'Ioannis',
 'armed', 'A', 'AKM6872');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Petridis', 'active',
 'Papandreou 115', 'Heraklion', '1',
 'Vasiliki', '6901870705', 'Leonidas',
 'armed', 'A', 'OCN3312');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Lazaridis', 'active',
 'Solonos 77', 'Chania', '1',
 'Eleni', '6945552272', 'Michail',
 'armed', 'A', 'ZBG6887');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Zafeiris', 'active',
 'Papandreou 79', 'Patra', '1',
 'Vasiliki', '6929818662', 'Konstantinos',
 'armed', 'A', 'CMK3719');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Solonos 153', 'Thessaloniki', '1',
 'Vasiliki', '6970604106', 'Konstantinos',
 'armed', 'A', 'KKJ8076');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Alexopoulos', 'active',
 'Platonos 176', 'Chania', '1',
 'Maria', '6972848009', 'Stelios',
 'armed', 'A', 'HSH1422');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Christou', 'active',
 'Perikleous 99', 'Athens', '1',
 'Ioanna', '6930480652', 'Ioannis',
 'armed', 'A', 'VVE3205');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Georgiou', 'active',
 'Sokratous 2', 'Athens', '1',
 'Anna', '6902289481', 'Georgios',
 'armed', 'A', 'TRN6603');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Karalis', 'active',
 'Omirou 28', 'Kavala', '1',
 'Katerina', '6907255698', 'Ioannis',
 'armed', 'A', 'DZU2019');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Petridis', 'active',
 'Sokratous 170', 'Komotini', '1',
 'Eirini', '6906324053', 'Theodoros',
 'armed', 'A', 'VKA6032');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Papadopoulos', 'active',
 'Karaiskaki 99', 'Thessaloniki', '1',
 'Sofia', '6909269377', 'Vasileios',
 'armed', 'A', 'CNB9911');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Venizelou 87', 'Heraklion', '1',
 'Vasiliki', '6940385329', 'Manolis',
 'armed', 'A', 'AYD2228');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Kotsis', 'active',
 'Solonos 186', 'Kavala', '1',
 'Sofia', '6907317753', 'Michail',
 'armed', 'A', 'DCT6631');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Kotsis', 'active',
 'Solonos 96', 'Volos', '1',
 'Anna', '6922512519', 'Stelios',
 'armed', 'A', 'IVY8892');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Nikolaidis', 'active',
 'Venizelou 190', 'Athens', '1',
 'Anna', '6906404885', 'Konstantinos',
 'armed', 'A', 'LFB6516');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Zafeiris', 'active',
 'Vempo Sophias 164', 'Volos', '1',
 'Sofia', '6918579886', 'Petros',
 'armed', 'A', 'KJQ5951');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Dedes', 'active',
 'Sokratous 177', 'Volos', '1',
 'Eleni', '6961996258', 'Konstantinos',
 'armed', 'A', 'MCO6371');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Alexopoulos', 'active',
 'Omirou 131', 'Kavala', '1',
 'Eirini', '6977829830', 'Petros',
 'armed', 'A', 'GPP0511');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Karaiskaki 60', 'Athens', '1',
 'Georgia', '6960286855', 'Anastasios',
 'armed', 'A', 'KZO0980');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Nikolaidis', 'active',
 'Solonos 193', 'Serres', '1',
 'Vasiliki', '6952141270', 'Stelios',
 'armed', 'A', 'BJZ0759');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Spanos', 'active',
 'Omirou 168', 'Heraklion', '1',
 'Sofia', '6940349649', 'Christos',
 'armed', 'A', 'CVR3744');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Petridis', 'active',
 'Omirou 157', 'Heraklion', '1',
 'Ioanna', '6968838151', 'Michail',
 'armed', 'A', 'QII7410');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Nikolaidis', 'active',
 'Venizelou 175', 'Chania', '1',
 'Georgia', '6966408127', 'Anastasios',
 'armed', 'A', 'UXV6312');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Petridis', 'active',
 'Karaiskaki 41', 'Kavala', '1',
 'Eleni', '6989867263', 'Michail',
 'armed', 'A', 'KRH3731');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Christou', 'active',
 'Venizelou 150', 'Patra', '1',
 'Katerina', '6923672118', 'Christos',
 'armed', 'A', 'BDL2679');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Karalis', 'active',
 'Platonos 129', 'Thessaloniki', '1',
 'Georgia', '6975292138', 'Sotirios',
 'unarmed', 'A', 'PRB3398');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Lazaridis', 'active',
 'Venizelou 64', 'Serres', '1',
 'Georgia', '6908859647', 'Konstantinos',
 'unarmed', 'A', 'EMX6417');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Georgiou', 'active',
 'Perikleous 110', 'Athens', '1',
 'Vasiliki', '6939219697', 'Anastasios',
 'armed', 'A', 'BCU4382');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Papadopoulos', 'active',
 'Platonos 6', 'Heraklion', '1',
 'Maria', '6902567525', 'Christos',
 'armed', 'A', 'JGF6804');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Mantzouranis', 'active',
 'Venizelou 108', 'Volos', '1',
 'Sofia', '6966627793', 'Pavlos',
 'armed', 'A', 'TBP7162');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Athanasiadis', 'active',
 'Papandreou 185', 'Komotini', '1',
 'Sofia', '6935949921', 'Vasileios',
 'armed', 'A', 'POI8542');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Solonos 167', 'Kavala', '1',
 'Anna', '6968870117', 'Manolis',
 'armed', 'A', 'CKL6552');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Dedes', 'active',
 'Sokratous 20', 'Kavala', '1',
 'Maria', '6959371999', 'Vasileios',
 'unarmed', 'A', 'CIU9523');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Spanos', 'active',
 'Solonos 66', 'Patra', '1',
 'Vasiliki', '6935259687', 'Konstantinos',
 'unarmed', 'A', 'MRT1301');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Lazaridis', 'active',
 'Karaiskaki 187', 'Patra', '1',
 'Sofia', '6911634848', 'Konstantinos',
 'armed', 'A', 'JAR9483');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Lazaridis', 'active',
 'Papandreou 177', 'Athens', '1',
 'Dimitra', '6991887296', 'Stelios',
 'armed', 'A', 'KYT0788');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Karaiskaki 20', 'Larisa', '1',
 'Maria', '6932599223', 'Manolis',
 'armed', 'A', 'NLP5160');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Lazaridis', 'active',
 'Perikleous 124', 'Thessaloniki', '1',
 'Eirini', '6986991664', 'Petros',
 'armed', 'A', 'VLI2693');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Lazaridis', 'active',
 'Omirou 92', 'Patra', '1',
 'Eirini', '6914816594', 'Christos',
 'armed', 'A', 'CDN4865');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Georgiou', 'active',
 'Platonos 186', 'Athens', '1',
 'Ioanna', '6995360848', 'Petros',
 'unarmed', 'A', 'JUC6031');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Alexopoulos', 'active',
 'Karaiskaki 95', 'Serres', '1',
 'Sofia', '6989502661', 'Anastasios',
 'armed', 'A', 'OSS9208');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Papandreou 62', 'Volos', '1',
 'Maria', '6909545330', 'Konstantinos',
 'armed', 'A', 'NRH6882');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Ioannou', 'active',
 'Karaiskaki 163', 'Volos', '1',
 'Anna', '6968795059', 'Sotirios',
 'armed', 'A', 'OSQ6188');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Papandreou 44', 'Chania', '1',
 'Ioanna', '6935240134', 'Vasileios',
 'armed', 'A', 'MXT6335');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Georgiou', 'active',
 'Omirou 71', 'Volos', '1',
 'Katerina', '6904745296', 'Ioannis',
 'armed', 'A', 'IGP9049');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Papadopoulos', 'active',
 'Sokratous 6', 'Thessaloniki', '1',
 'Vasiliki', '6993653913', 'Manolis',
 'armed', 'A', 'XBC8044');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Zafeiris', 'active',
 'Omirou 194', 'Athens', '1',
 'Sofia', '6939515603', 'Stelios',
 'armed', 'A', 'OYI7191');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Platonos 118', 'Chania', '1',
 'Eleni', '6921392597', 'Petros',
 'armed', 'A', 'AWS1354');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Georgiou', 'active',
 'Papandreou 118', 'Thessaloniki', '1',
 'Vasiliki', '6927024689', 'Vasileios',
 'armed', 'A', 'MVG4016');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Petridis', 'active',
 'Sokratous 171', 'Chania', '1',
 'Vasiliki', '6965433028', 'Ioannis',
 'armed', 'A', 'UXR3293');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Panagiotou', 'active',
 'Karaiskaki 2', 'Thessaloniki', '1',
 'Georgia', '6905436769', 'Michail',
 'armed', 'A', 'AYS9770');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Mantzouranis', 'active',
 'Vempo Sophias 162', 'Serres', '1',
 'Eirini', '6981368050', 'Thanasis',
 'armed', 'A', 'ATV3769');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Spanos', 'active',
 'Sokratous 179', 'Larisa', '1',
 'Eleni', '6972833529', 'Manolis',
 'armed', 'A', 'GWZ4404');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Platonos 38', 'Komotini', '1',
 'Dimitra', '6982870469', 'Michail',
 'armed', 'A', 'FJD2325');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Georgiou', 'active',
 'Karaiskaki 61', 'Patra', '1',
 'Eleni', '6910959457', 'Stelios',
 'armed', 'A', 'MWZ8575');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Kotsis', 'active',
 'Omirou 94', 'Chania', '1',
 'Eirini', '6933966546', 'Stelios',
 'armed', 'A', 'MSK9747');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Panagiotou', 'active',
 'Vempo Sophias 105', 'Heraklion', '1',
 'Eirini', '6990688019', 'Georgios',
 'armed', 'A', 'ZCX5425');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Nikolaidis', 'active',
 'Vempo Sophias 174', 'Larisa', '1',
 'Katerina', '6935700542', 'Petros',
 'armed', 'A', 'RMH4848');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Alexopoulos', 'active',
 'Vempo Sophias 77', 'Serres', '1',
 'Vasiliki', '6955992939', 'Alexandros',
 'armed', 'A', 'ZYE0963');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Spanos', 'active',
 'Sokratous 34', 'Serres', '1',
 'Vasiliki', '6906003837', 'Stelios',
 'armed', 'A', 'WLD3861');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Nikolaidis', 'active',
 'Platonos 160', 'Komotini', '1',
 'Eirini', '6976565521', 'Georgios',
 'armed', 'A', 'RHR7845');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Georgiou', 'active',
 'Platonos 40', 'Serres', '1',
 'Anna', '6969569475', 'Anastasios',
 'armed', 'A', 'MZM6737');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Zafeiris', 'active',
 'Vempo Sophias 169', 'Athens', '1',
 'Dimitra', '6976502588', 'Alexandros',
 'armed', 'A', 'VZS1641');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Papandreou 178', 'Thessaloniki', '1',
 'Eirini', '6928525731', 'Theodoros',
 'unarmed', 'A', 'UKL4870');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Karalis', 'active',
 'Solonos 189', 'Larisa', '1',
 'Sofia', '6993691549', 'Vasileios',
 'armed', 'A', 'FYC9760');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Papadopoulos', 'active',
 'Karaiskaki 200', 'Larisa', '1',
 'Georgia', '6901744941', 'Alexandros',
 'armed', 'A', 'PDK3003');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Spanos', 'active',
 'Sokratous 195', 'Patra', '1',
 'Sofia', '6912380200', 'Anastasios',
 'armed', 'A', 'IFT3174');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Nikolaidis', 'active',
 'Vempo Sophias 79', 'Athens', '1',
 'Maria', '6908717314', 'Konstantinos',
 'unarmed', 'A', 'ZTI6026');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Christou', 'active',
 'Papandreou 14', 'Patra', '1',
 'Anna', '6967718588', 'Thanasis',
 'armed', 'A', 'FAO8213');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Alexopoulos', 'active',
 'Karaiskaki 137', 'Patra', '1',
 'Ioanna', '6917988031', 'Petros',
 'armed', 'A', 'TPW8063');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Spanos', 'active',
 'Platonos 16', 'Kavala', '1',
 'Georgia', '6987123947', 'Ioannis',
 'armed', 'A', 'FOP5655');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Alexopoulos', 'active',
 'Solonos 149', 'Athens', '1',
 'Georgia', '6928022718', 'Pavlos',
 'armed', 'A', 'UMC2387');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Spanos', 'active',
 'Solonos 16', 'Heraklion', '1',
 'Dimitra', '6955578305', 'Leonidas',
 'armed', 'A', 'JUE2928');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Mantzouranis', 'active',
 'Papandreou 36', 'Athens', '1',
 'Georgia', '6962697923', 'Stelios',
 'unarmed', 'A', 'LTX2719');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Papandreou 158', 'Larisa', '1',
 'Sofia', '6992965207', 'Thanasis',
 'armed', 'A', 'EHG1666');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Theodorakis', 'active',
 'Sokratous 8', 'Kavala', '1',
 'Katerina', '6958113676', 'Alexandros',
 'armed', 'A', 'XUK1166');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Sokratous 181', 'Chania', '1',
 'Maria', '6988648670', 'Alexandros',
 'unarmed', 'A', 'DGG9753');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Christou', 'active',
 'Perikleous 104', 'Kavala', '1',
 'Maria', '6972967178', 'Sotirios',
 'armed', 'A', 'ULJ9663');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Athanasiadis', 'active',
 'Karaiskaki 52', 'Larisa', '1',
 'Sofia', '6930835660', 'Michail',
 'armed', 'A', 'XGV3787');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Karaiskaki 1', 'Thessaloniki', '1',
 'Georgia', '6947524347', 'Sotirios',
 'armed', 'A', 'VKT8493');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Papadopoulos', 'active',
 'Papandreou 163', 'Kavala', '1',
 'Eirini', '6904375023', 'Manolis',
 'armed', 'A', 'DYL0304');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Mantzouranis', 'active',
 'Platonos 83', 'Komotini', '1',
 'Vasiliki', '6933588610', 'Manolis',
 'armed', 'A', 'LII7817');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Kotsis', 'active',
 'Solonos 106', 'Chania', '1',
 'Sofia', '6960022273', 'Christos',
 'armed', 'A', 'FWV6719');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Kotsis', 'active',
 'Platonos 188', 'Kavala', '1',
 'Dimitra', '6925687201', 'Vasileios',
 'armed', 'A', 'WLN3104');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Papadopoulos', 'active',
 'Omirou 147', 'Heraklion', '1',
 'Vasiliki', '6905894940', 'Sotirios',
 'armed', 'A', 'NZS3929');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Christou', 'active',
 'Sokratous 152', 'Komotini', '1',
 'Sofia', '6963958441', 'Thanasis',
 'unarmed', 'A', 'RKJ9438');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Alexopoulos', 'active',
 'Platonos 40', 'Komotini', '1',
 'Georgia', '6900961604', 'Vasileios',
 'armed', 'A', 'HML6839');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Ioannou', 'active',
 'Sokratous 37', 'Thessaloniki', '1',
 'Dimitra', '6984356443', 'Vasileios',
 'unarmed', 'A', 'QBX0585');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Christou', 'active',
 'Solonos 161', 'Thessaloniki', '1',
 'Eirini', '6957750542', 'Thanasis',
 'armed', 'A', 'ZVG1910');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Ioannou', 'active',
 'Solonos 190', 'Heraklion', '1',
 'Sofia', '6913914329', 'Alexandros',
 'armed', 'A', 'KPK4846');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Zafeiris', 'active',
 'Sokratous 77', 'Kavala', '1',
 'Sofia', '6901404395', 'Alexandros',
 'armed', 'A', 'YZH4433');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Theodorakis', 'active',
 'Venizelou 181', 'Serres', '1',
 'Katerina', '6962287186', 'Anastasios',
 'armed', 'A', 'RPC9203');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Nikolaidis', 'active',
 'Omirou 39', 'Heraklion', '1',
 'Eleni', '6900017171', 'Alexandros',
 'armed', 'A', 'XPZ0492');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Dedes', 'active',
 'Omirou 49', 'Komotini', '1',
 'Georgia', '6935786159', 'Vasileios',
 'armed', 'A', 'BXK7158');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Perikleous 4', 'Athens', '1',
 'Vasiliki', '6984392363', 'Manolis',
 'armed', 'A', 'BNK3520');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Papadopoulos', 'active',
 'Karaiskaki 154', 'Volos', '1',
 'Georgia', '6971894684', 'Leonidas',
 'armed', 'A', 'RDR6796');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Alexopoulos', 'active',
 'Karaiskaki 1', 'Volos', '1',
 'Maria', '6978782121', 'Petros',
 'armed', 'A', 'BCK6025');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Perikleous 81', 'Komotini', '1',
 'Maria', '6993059499', 'Konstantinos',
 'armed', 'A', 'KEO8429');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Athanasiadis', 'active',
 'Solonos 32', 'Komotini', '1',
 'Katerina', '6958589797', 'Vasileios',
 'armed', 'A', 'SWG0949');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Alexopoulos', 'active',
 'Papandreou 73', 'Larisa', '1',
 'Dimitra', '6942121745', 'Manolis',
 'armed', 'A', 'UQB4876');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Petridis', 'active',
 'Perikleous 66', 'Kavala', '1',
 'Vasiliki', '6919222097', 'Ioannis',
 'armed', 'A', 'HXA7250');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Papandreou 38', 'Chania', '1',
 'Katerina', '6985644163', 'Christos',
 'unarmed', 'A', 'OLA8468');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Karalis', 'active',
 'Omirou 32', 'Patra', '1',
 'Anna', '6956416161', 'Michail',
 'armed', 'A', 'LDC4219');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Omirou 188', 'Chania', '1',
 'Ioanna', '6979921308', 'Leonidas',
 'armed', 'A', 'PTP9423');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Athanasiadis', 'active',
 'Omirou 64', 'Larisa', '1',
 'Anna', '6931375015', 'Vasileios',
 'armed', 'A', 'ESQ6530');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Lazaridis', 'active',
 'Solonos 16', 'Chania', '1',
 'Anna', '6949871772', 'Manolis',
 'armed', 'A', 'XBQ5955');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Nikolaidis', 'active',
 'Omirou 168', 'Volos', '1',
 'Sofia', '6990012269', 'Christos',
 'armed', 'A', 'YAD2400');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Athanasiadis', 'active',
 'Venizelou 96', 'Serres', '1',
 'Maria', '6948155306', 'Pavlos',
 'unarmed', 'A', 'SDE8510');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Nikolaidis', 'active',
 'Perikleous 56', 'Serres', '1',
 'Eirini', '6995348993', 'Sotirios',
 'armed', 'A', 'CMS7346');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Solonos 42', 'Serres', '1',
 'Ioanna', '6906132779', 'Sotirios',
 'armed', 'A', 'QTC0781');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Christou', 'active',
 'Vempo Sophias 16', 'Athens', '1',
 'Ioanna', '6956361037', 'Petros',
 'armed', 'A', 'TWE5873');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Ioannou', 'active',
 'Karaiskaki 178', 'Kavala', '1',
 'Ioanna', '6912914976', 'Michail',
 'armed', 'A', 'TQC2306');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Mantzouranis', 'active',
 'Platonos 40', 'Serres', '1',
 'Ioanna', '6996589105', 'Michail',
 'armed', 'A', 'BYO6735');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Dedes', 'active',
 'Perikleous 39', 'Larisa', '1',
 'Georgia', '6921590603', 'Thanasis',
 'armed', 'A', 'HRC4983');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Christou', 'active',
 'Sokratous 107', 'Komotini', '1',
 'Georgia', '6926219091', 'Theodoros',
 'armed', 'A', 'AJG5682');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Georgiou', 'active',
 'Platonos 118', 'Kavala', '1',
 'Sofia', '6974283983', 'Christos',
 'armed', 'A', 'FBD3360');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Lazaridis', 'active',
 'Platonos 12', 'Heraklion', '1',
 'Dimitra', '6940275847', 'Michail',
 'armed', 'A', 'DGV7703');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Georgiou', 'active',
 'Platonos 163', 'Patra', '1',
 'Georgia', '6997185499', 'Ioannis',
 'armed', 'A', 'YCE2339');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Athanasiadis', 'active',
 'Papandreou 132', 'Komotini', '1',
 'Maria', '6930831312', 'Konstantinos',
 'unarmed', 'A', 'YPO8772');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Georgiou', 'active',
 'Venizelou 116', 'Thessaloniki', '1',
 'Ioanna', '6991296379', 'Alexandros',
 'armed', 'A', 'WUY6844');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Dedes', 'active',
 'Perikleous 180', 'Komotini', '1',
 'Eirini', '6969435921', 'Ioannis',
 'armed', 'A', 'LPJ1015');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Zafeiris', 'active',
 'Omirou 140', 'Serres', '1',
 'Anna', '6935915774', 'Michail',
 'armed', 'A', 'UGX8357');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Venizelou 98', 'Kavala', '1',
 'Eleni', '6946911406', 'Petros',
 'armed', 'A', 'ZNH1545');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Papandreou 188', 'Serres', '1',
 'Anna', '6976236671', 'Alexandros',
 'armed', 'A', 'IMV0673');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Christou', 'active',
 'Omirou 95', 'Patra', '1',
 'Eleni', '6930637610', 'Ioannis',
 'armed', 'A', 'PUI7158');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Perikleous 70', 'Larisa', '1',
 'Dimitra', '6980348025', 'Georgios',
 'armed', 'A', 'NQQ2583');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Dedes', 'active',
 'Sokratous 24', 'Patra', '1',
 'Katerina', '6972660476', 'Michail',
 'armed', 'A', 'WDR9351');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Alexopoulos', 'active',
 'Perikleous 171', 'Serres', '1',
 'Vasiliki', '6924288345', 'Sotirios',
 'armed', 'A', 'YKQ0310');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Karalis', 'active',
 'Vempo Sophias 44', 'Athens', '1',
 'Maria', '6953388556', 'Vasileios',
 'armed', 'A', 'MSW2487');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Zafeiris', 'active',
 'Karaiskaki 153', 'Larisa', '1',
 'Dimitra', '6954044380', 'Thanasis',
 'armed', 'A', 'JDZ8654');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Panagiotou', 'active',
 'Venizelou 135', 'Kavala', '1',
 'Dimitra', '6965856787', 'Alexandros',
 'armed', 'A', 'GNP8356');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Solonos 117', 'Chania', '1',
 'Ioanna', '6978054872', 'Vasileios',
 'armed', 'A', 'NFO5871');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Georgiou', 'active',
 'Karaiskaki 156', 'Patra', '1',
 'Ioanna', '6970337070', 'Thanasis',
 'armed', 'A', 'BAU6805');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Vempo Sophias 66', 'Kavala', '1',
 'Vasiliki', '6920768842', 'Ioannis',
 'armed', 'A', 'GYE5530');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Ioannou', 'active',
 'Solonos 66', 'Athens', '1',
 'Eleni', '6934457690', 'Ioannis',
 'armed', 'A', 'QNP8727');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Alexopoulos', 'active',
 'Sokratous 150', 'Chania', '1',
 'Ioanna', '6992165647', 'Konstantinos',
 'armed', 'A', 'SWQ5588');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Alexopoulos', 'active',
 'Omirou 151', 'Komotini', '1',
 'Eirini', '6980717550', 'Georgios',
 'armed', 'A', 'ASB1138');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Panagiotou', 'active',
 'Vempo Sophias 35', 'Patra', '1',
 'Katerina', '6940954902', 'Ioannis',
 'armed', 'A', 'IUT1394');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Kotsis', 'active',
 'Karaiskaki 147', 'Thessaloniki', '1',
 'Katerina', '6990547600', 'Leonidas',
 'armed', 'A', 'KGM0667');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Georgiou', 'active',
 'Solonos 79', 'Kavala', '1',
 'Georgia', '6944693092', 'Ioannis',
 'unarmed', 'A', 'SBH2662');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Christou', 'active',
 'Solonos 165', 'Patra', '1',
 'Vasiliki', '6954525745', 'Pavlos',
 'armed', 'A', 'MPV1089');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Christou', 'active',
 'Venizelou 9', 'Chania', '1',
 'Georgia', '6979709090', 'Theodoros',
 'armed', 'A', 'DUJ9223');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Papadopoulos', 'active',
 'Papandreou 100', 'Kavala', '1',
 'Maria', '6917094713', 'Georgios',
 'armed', 'A', 'BNT1052');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Papandreou 15', 'Patra', '1',
 'Ioanna', '6934536646', 'Christos',
 'unarmed', 'A', 'RGH9160');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Papadopoulos', 'active',
 'Papandreou 31', 'Athens', '1',
 'Ioanna', '6986794769', 'Michail',
 'armed', 'A', 'UHU9326');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Vempo Sophias 177', 'Heraklion', '1',
 'Katerina', '6982326712', 'Thanasis',
 'armed', 'A', 'TGP6855');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Ioannou', 'active',
 'Omirou 26', 'Kavala', '1',
 'Maria', '6952196225', 'Alexandros',
 'armed', 'A', 'FXK9729');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Dedes', 'active',
 'Perikleous 187', 'Athens', '1',
 'Vasiliki', '6918333142', 'Konstantinos',
 'armed', 'A', 'UUG5628');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Karalis', 'active',
 'Karaiskaki 34', 'Thessaloniki', '1',
 'Ioanna', '6980336427', 'Stelios',
 'armed', 'A', 'PHU8060');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Papadopoulos', 'active',
 'Vempo Sophias 155', 'Volos', '1',
 'Georgia', '6964893999', 'Sotirios',
 'unarmed', 'A', 'DLU2840');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Lazaridis', 'active',
 'Vempo Sophias 1', 'Patra', '1',
 'Katerina', '6947719877', 'Alexandros',
 'armed', 'A', 'RDO4586');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Papadopoulos', 'active',
 'Venizelou 1', 'Athens', '1',
 'Maria', '6993395755', 'Anastasios',
 'armed', 'A', 'UPF3826');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Dedes', 'active',
 'Venizelou 104', 'Athens', '1',
 'Dimitra', '6958740540', 'Thanasis',
 'armed', 'A', 'KXV4055');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Athanasiadis', 'active',
 'Vempo Sophias 31', 'Chania', '1',
 'Dimitra', '6913133019', 'Stelios',
 'armed', 'A', 'YLL4213');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Sokratous 80', 'Kavala', '1',
 'Vasiliki', '6900285950', 'Thanasis',
 'armed', 'A', 'CXE3810');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Perikleous 156', 'Heraklion', '1',
 'Eirini', '6925213676', 'Manolis',
 'armed', 'A', 'GNL5664');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Athanasiadis', 'active',
 'Sokratous 42', 'Athens', '1',
 'Ioanna', '6924681795', 'Georgios',
 'unarmed', 'A', 'BWG3305');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Zafeiris', 'active',
 'Perikleous 30', 'Serres', '1',
 'Eleni', '6934748683', 'Sotirios',
 'armed', 'A', 'DYM9662');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Ioannou', 'active',
 'Solonos 74', 'Komotini', '1',
 'Vasiliki', '6945001824', 'Vasileios',
 'armed', 'A', 'UHC5935');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Kotsis', 'active',
 'Platonos 95', 'Kavala', '1',
 'Ioanna', '6964169195', 'Pavlos',
 'unarmed', 'A', 'JST4766');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Athanasiadis', 'active',
 'Papandreou 44', 'Serres', '1',
 'Katerina', '6958364387', 'Theodoros',
 'armed', 'A', 'XTR8855');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Papadopoulos', 'active',
 'Vempo Sophias 76', 'Serres', '1',
 'Anna', '6972723553', 'Leonidas',
 'armed', 'A', 'TFI6494');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Georgiou', 'active',
 'Papandreou 64', 'Athens', '1',
 'Eirini', '6967340784', 'Georgios',
 'armed', 'A', 'CFI4614');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Karaiskaki 93', 'Heraklion', '1',
 'Dimitra', '6925205755', 'Georgios',
 'armed', 'A', 'FGU6530');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Nikolaidis', 'active',
 'Karaiskaki 185', 'Athens', '1',
 'Dimitra', '6907464157', 'Sotirios',
 'unarmed', 'A', 'IQJ3251');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Papadopoulos', 'active',
 'Perikleous 56', 'Chania', '1',
 'Eirini', '6937923049', 'Vasileios',
 'armed', 'A', 'KYC1450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Athanasiadis', 'active',
 'Solonos 175', 'Larisa', '1',
 'Eleni', '6923494901', 'Michail',
 'armed', 'A', 'PXD2267');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Karalis', 'active',
 'Platonos 82', 'Kavala', '1',
 'Georgia', '6915301642', 'Sotirios',
 'armed', 'A', 'BIJ1446');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Theodorakis', 'active',
 'Solonos 57', 'Chania', '1',
 'Eirini', '6915394317', 'Petros',
 'armed', 'A', 'WJC1205');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Athanasiadis', 'active',
 'Perikleous 194', 'Thessaloniki', '1',
 'Eirini', '6977232586', 'Pavlos',
 'armed', 'A', 'NMC6155');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Venizelou 111', 'Kavala', '1',
 'Vasiliki', '6925819218', 'Michail',
 'armed', 'A', 'UCJ1140');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Sokratous 173', 'Kavala', '1',
 'Maria', '6983921661', 'Michail',
 'armed', 'A', 'DSC9328');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Christou', 'active',
 'Vempo Sophias 34', 'Kavala', '1',
 'Vasiliki', '6936450369', 'Manolis',
 'armed', 'A', 'PMP2497');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Alexopoulos', 'active',
 'Omirou 153', 'Larisa', '1',
 'Maria', '6933392525', 'Alexandros',
 'armed', 'A', 'GYQ4623');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Alexopoulos', 'active',
 'Sokratous 34', 'Volos', '1',
 'Katerina', '6999349082', 'Konstantinos',
 'armed', 'A', 'ZMO4400');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Zafeiris', 'active',
 'Platonos 17', 'Larisa', '1',
 'Katerina', '6949270100', 'Leonidas',
 'armed', 'A', 'UGL9779');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Theodorakis', 'active',
 'Omirou 99', 'Patra', '1',
 'Dimitra', '6975673677', 'Alexandros',
 'armed', 'A', 'YAH3923');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Georgiou', 'active',
 'Platonos 172', 'Kavala', '1',
 'Georgia', '6982323328', 'Christos',
 'armed', 'A', 'EBW5384');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Ioannou', 'active',
 'Sokratous 176', 'Heraklion', '1',
 'Vasiliki', '6949261137', 'Ioannis',
 'armed', 'A', 'YKJ5362');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Panagiotou', 'active',
 'Sokratous 104', 'Thessaloniki', '1',
 'Ioanna', '6902082066', 'Manolis',
 'armed', 'A', 'QWF3352');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Theodorakis', 'active',
 'Papandreou 188', 'Athens', '1',
 'Maria', '6996155813', 'Theodoros',
 'armed', 'A', 'TDD8842');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Kotsis', 'active',
 'Omirou 47', 'Komotini', '1',
 'Vasiliki', '6946044985', 'Pavlos',
 'armed', 'A', 'BVE9502');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Sokratous 75', 'Serres', '1',
 'Georgia', '6995527600', 'Anastasios',
 'unarmed', 'A', 'YPY8034');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Dedes', 'active',
 'Solonos 146', 'Athens', '1',
 'Anna', '6938015318', 'Pavlos',
 'unarmed', 'A', 'WGN0521');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Spanos', 'active',
 'Karaiskaki 135', 'Komotini', '1',
 'Katerina', '6989094570', 'Leonidas',
 'armed', 'A', 'EHE2911');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Omirou 6', 'Thessaloniki', '1',
 'Katerina', '6991654098', 'Anastasios',
 'armed', 'A', 'FUK5621');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Solonos 151', 'Thessaloniki', '1',
 'Katerina', '6945438197', 'Pavlos',
 'armed', 'A', 'UVL8536');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Papandreou 151', 'Heraklion', '1',
 'Georgia', '6989558577', 'Stelios',
 'armed', 'A', 'GLT7135');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Ioannou', 'active',
 'Omirou 7', 'Thessaloniki', '1',
 'Ioanna', '6991419656', 'Michail',
 'armed', 'A', 'XJT6635');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Petridis', 'active',
 'Vempo Sophias 129', 'Volos', '1',
 'Eirini', '6915683907', 'Michail',
 'armed', 'A', 'QSM2164');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Solonos 71', 'Volos', '1',
 'Sofia', '6927772258', 'Sotirios',
 'armed', 'A', 'XKO5607');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Papadopoulos', 'active',
 'Omirou 198', 'Komotini', '1',
 'Eirini', '6939985094', 'Pavlos',
 'unarmed', 'A', 'YED0028');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Panagiotou', 'active',
 'Perikleous 100', 'Komotini', '1',
 'Eirini', '6959078325', 'Theodoros',
 'armed', 'A', 'GCM7095');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Mantzouranis', 'active',
 'Papandreou 36', 'Chania', '1',
 'Georgia', '6936545801', 'Ioannis',
 'unarmed', 'A', 'SUB7807');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Christou', 'active',
 'Karaiskaki 172', 'Kavala', '1',
 'Vasiliki', '6903915895', 'Christos',
 'armed', 'A', 'FVL6313');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Panagiotou', 'active',
 'Papandreou 85', 'Patra', '1',
 'Ioanna', '6901093845', 'Sotirios',
 'unarmed', 'A', 'NZC9285');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Venizelou 127', 'Athens', '1',
 'Eirini', '6983134496', 'Anastasios',
 'armed', 'A', 'FJF5901');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Georgiou', 'active',
 'Omirou 90', 'Volos', '1',
 'Ioanna', '6967771945', 'Sotirios',
 'armed', 'A', 'BDT3532');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Zafeiris', 'active',
 'Platonos 116', 'Thessaloniki', '1',
 'Eirini', '6968553882', 'Georgios',
 'armed', 'A', 'SZR4399');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Karaiskaki 35', 'Chania', '1',
 'Dimitra', '6928640781', 'Sotirios',
 'armed', 'A', 'ZMK7739');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Athanasiadis', 'active',
 'Vempo Sophias 74', 'Komotini', '1',
 'Eirini', '6901353223', 'Sotirios',
 'armed', 'A', 'GFL9279');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Ioannou', 'active',
 'Platonos 141', 'Patra', '1',
 'Dimitra', '6961947383', 'Vasileios',
 'unarmed', 'A', 'LWC6609');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Platonos 24', 'Chania', '1',
 'Ioanna', '6924423491', 'Theodoros',
 'armed', 'A', 'EBJ9290');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Nikolaidis', 'active',
 'Perikleous 182', 'Patra', '1',
 'Eirini', '6958600775', 'Ioannis',
 'armed', 'A', 'WOE3485');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Kotsis', 'active',
 'Venizelou 3', 'Patra', '1',
 'Maria', '6957078881', 'Konstantinos',
 'armed', 'A', 'JTC9402');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Petridis', 'active',
 'Papandreou 168', 'Serres', '1',
 'Eleni', '6982989542', 'Petros',
 'armed', 'A', 'SFO9885');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Zafeiris', 'active',
 'Papandreou 135', 'Athens', '1',
 'Dimitra', '6943442657', 'Pavlos',
 'armed', 'A', 'JQT0440');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Vempo Sophias 189', 'Komotini', '1',
 'Dimitra', '6973526940', 'Michail',
 'unarmed', 'A', 'SKH5754');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Panagiotou', 'active',
 'Vempo Sophias 132', 'Patra', '1',
 'Eirini', '6970386322', 'Manolis',
 'unarmed', 'A', 'FQT5618');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Dedes', 'active',
 'Karaiskaki 104', 'Volos', '1',
 'Dimitra', '6992547967', 'Michail',
 'armed', 'A', 'FOL2335');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Lazaridis', 'active',
 'Papandreou 121', 'Volos', '1',
 'Eirini', '6933228751', 'Pavlos',
 'armed', 'A', 'GQX1474');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Zafeiris', 'active',
 'Omirou 197', 'Volos', '1',
 'Vasiliki', '6960545160', 'Thanasis',
 'unarmed', 'A', 'KKE2605');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Zafeiris', 'active',
 'Platonos 138', 'Athens', '1',
 'Vasiliki', '6994527187', 'Vasileios',
 'armed', 'A', 'MKJ6747');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Spanos', 'active',
 'Papandreou 175', 'Komotini', '1',
 'Eirini', '6918100875', 'Konstantinos',
 'armed', 'A', 'OAE4241');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Georgiou', 'active',
 'Karaiskaki 171', 'Chania', '1',
 'Katerina', '6996465133', 'Leonidas',
 'armed', 'A', 'OLX2660');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Zafeiris', 'active',
 'Karaiskaki 75', 'Athens', '1',
 'Ioanna', '6960647721', 'Georgios',
 'armed', 'A', 'YQS5856');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Papadopoulos', 'active',
 'Platonos 86', 'Chania', '1',
 'Georgia', '6932989373', 'Ioannis',
 'armed', 'A', 'BDW7274');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Christou', 'active',
 'Perikleous 12', 'Heraklion', '1',
 'Sofia', '6954175379', 'Sotirios',
 'armed', 'A', 'DWQ7272');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Lazaridis', 'active',
 'Sokratous 67', 'Larisa', '1',
 'Sofia', '6981154314', 'Georgios',
 'armed', 'A', 'ZXN1062');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Panagiotou', 'active',
 'Vempo Sophias 131', 'Patra', '1',
 'Ioanna', '6905971607', 'Ioannis',
 'armed', 'A', 'QEZ4179');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Platonos 93', 'Patra', '1',
 'Katerina', '6962776791', 'Vasileios',
 'unarmed', 'A', 'BNT3322');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Nikolaidis', 'active',
 'Vempo Sophias 8', 'Kavala', '1',
 'Katerina', '6905357080', 'Vasileios',
 'armed', 'A', 'JHK2856');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Lazaridis', 'active',
 'Platonos 7', 'Thessaloniki', '1',
 'Vasiliki', '6949733364', 'Manolis',
 'armed', 'A', 'YHP8869');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Solonos 8', 'Heraklion', '1',
 'Dimitra', '6924530247', 'Pavlos',
 'armed', 'A', 'CWM1545');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Georgiou', 'active',
 'Platonos 55', 'Thessaloniki', '1',
 'Katerina', '6940677045', 'Alexandros',
 'armed', 'A', 'IHB1124');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Sokratous 37', 'Athens', '1',
 'Eirini', '6961826867', 'Konstantinos',
 'armed', 'A', 'BVH7815');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Karalis', 'active',
 'Sokratous 52', 'Patra', '1',
 'Dimitra', '6986290470', 'Theodoros',
 'armed', 'A', 'VPH3386');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Zafeiris', 'active',
 'Papandreou 36', 'Athens', '1',
 'Georgia', '6901825758', 'Sotirios',
 'armed', 'A', 'HWG4289');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Ioannou', 'active',
 'Karaiskaki 15', 'Chania', '1',
 'Eleni', '6908809754', 'Manolis',
 'armed', 'A', 'SHA7558');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Karalis', 'active',
 'Papandreou 158', 'Komotini', '1',
 'Vasiliki', '6939988386', 'Sotirios',
 'armed', 'A', 'JEA4217');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Spanos', 'active',
 'Karaiskaki 84', 'Patra', '1',
 'Dimitra', '6920084938', 'Anastasios',
 'armed', 'A', 'ZZZ4029');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Spanos', 'active',
 'Vempo Sophias 156', 'Kavala', '1',
 'Anna', '6996049189', 'Konstantinos',
 'armed', 'A', 'ZGT9939');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Spanos', 'active',
 'Solonos 198', 'Komotini', '1',
 'Anna', '6912830625', 'Anastasios',
 'armed', 'A', 'JVL6350');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Ioannou', 'active',
 'Karaiskaki 129', 'Komotini', '1',
 'Vasiliki', '6903149717', 'Michail',
 'armed', 'A', 'KUB9655');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Mantzouranis', 'active',
 'Platonos 37', 'Komotini', '1',
 'Eleni', '6954200626', 'Theodoros',
 'armed', 'A', 'SHF8745');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Theodorakis', 'active',
 'Papandreou 90', 'Komotini', '1',
 'Sofia', '6925288183', 'Petros',
 'armed', 'A', 'YJQ8498');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Zafeiris', 'active',
 'Papandreou 32', 'Komotini', '1',
 'Vasiliki', '6990591682', 'Alexandros',
 'armed', 'A', 'JHV1883');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Zafeiris', 'active',
 'Solonos 31', 'Thessaloniki', '1',
 'Sofia', '6907874822', 'Pavlos',
 'armed', 'A', 'EDY2223');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Papadopoulos', 'active',
 'Papandreou 61', 'Heraklion', '1',
 'Dimitra', '6967769671', 'Manolis',
 'armed', 'A', 'UAA1468');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Kotsis', 'active',
 'Karaiskaki 78', 'Thessaloniki', '1',
 'Maria', '6936124874', 'Michail',
 'armed', 'A', 'TBG4674');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Kotsis', 'active',
 'Platonos 158', 'Kavala', '1',
 'Maria', '6939250317', 'Michail',
 'armed', 'A', 'CVF6587');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Nikolaidis', 'active',
 'Sokratous 2', 'Kavala', '1',
 'Sofia', '6941701211', 'Georgios',
 'armed', 'A', 'PEE2210');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Karalis', 'active',
 'Perikleous 120', 'Thessaloniki', '1',
 'Sofia', '6954745482', 'Theodoros',
 'armed', 'A', 'FHQ6998');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Petridis', 'active',
 'Solonos 156', 'Heraklion', '1',
 'Dimitra', '6963821376', 'Petros',
 'armed', 'A', 'CRO5002');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Solonos 87', 'Volos', '1',
 'Vasiliki', '6905989888', 'Thanasis',
 'armed', 'A', 'YAY9775');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Christou', 'active',
 'Omirou 199', 'Athens', '1',
 'Anna', '6926939933', 'Sotirios',
 'armed', 'A', 'POZ8382');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Zafeiris', 'active',
 'Karaiskaki 62', 'Chania', '1',
 'Georgia', '6951260995', 'Ioannis',
 'unarmed', 'A', 'QPG3144');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Kotsis', 'active',
 'Solonos 94', 'Patra', '1',
 'Vasiliki', '6985680014', 'Thanasis',
 'armed', 'A', 'KLL7544');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Georgiou', 'active',
 'Sokratous 49', 'Chania', '1',
 'Sofia', '6952710697', 'Ioannis',
 'armed', 'A', 'YVJ3348');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Lazaridis', 'active',
 'Venizelou 184', 'Larisa', '1',
 'Vasiliki', '6967972492', 'Thanasis',
 'armed', 'A', 'LGU7504');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Alexopoulos', 'active',
 'Solonos 17', 'Thessaloniki', '1',
 'Dimitra', '6981558380', 'Thanasis',
 'armed', 'A', 'BLS8719');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Lazaridis', 'active',
 'Platonos 147', 'Kavala', '1',
 'Katerina', '6929581436', 'Alexandros',
 'unarmed', 'A', 'HBU2682');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Spanos', 'active',
 'Karaiskaki 100', 'Larisa', '1',
 'Maria', '6922233085', 'Georgios',
 'armed', 'A', 'UPP6660');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Ioannou', 'active',
 'Vempo Sophias 59', 'Athens', '1',
 'Vasiliki', '6966529277', 'Anastasios',
 'armed', 'A', 'UQX9007');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Theodorakis', 'active',
 'Venizelou 128', 'Kavala', '1',
 'Dimitra', '6931674433', 'Theodoros',
 'armed', 'A', 'QLI4177');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Karalis', 'active',
 'Papandreou 136', 'Larisa', '1',
 'Katerina', '6979934309', 'Georgios',
 'armed', 'A', 'AOT4858');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Spanos', 'active',
 'Karaiskaki 179', 'Larisa', '1',
 'Katerina', '6933539066', 'Alexandros',
 'armed', 'A', 'OJP1180');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Vempo Sophias 145', 'Thessaloniki', '1',
 'Sofia', '6981898447', 'Thanasis',
 'armed', 'A', 'FBJ6695');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Ioannou', 'active',
 'Omirou 54', 'Patra', '1',
 'Dimitra', '6965569588', 'Christos',
 'armed', 'A', 'LOP3248');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Papadopoulos', 'active',
 'Papandreou 90', 'Larisa', '1',
 'Dimitra', '6965262157', 'Michail',
 'armed', 'A', 'TRD0922');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Kotsis', 'active',
 'Venizelou 198', 'Kavala', '1',
 'Dimitra', '6992076133', 'Stelios',
 'armed', 'A', 'VPO3144');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Kotsis', 'active',
 'Solonos 129', 'Athens', '1',
 'Eleni', '6920351537', 'Manolis',
 'armed', 'A', 'HWD9795');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Nikolaidis', 'active',
 'Platonos 29', 'Komotini', '1',
 'Anna', '6960052537', 'Alexandros',
 'unarmed', 'A', 'FLQ3490');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Zafeiris', 'active',
 'Venizelou 65', 'Athens', '1',
 'Ioanna', '6968805584', 'Manolis',
 'armed', 'A', 'WON0083');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Petridis', 'active',
 'Omirou 101', 'Volos', '1',
 'Eirini', '6972438674', 'Ioannis',
 'unarmed', 'A', 'DOG5865');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Georgiou', 'active',
 'Omirou 114', 'Larisa', '1',
 'Ioanna', '6935938766', 'Georgios',
 'armed', 'A', 'OGJ2025');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Ioannou', 'active',
 'Venizelou 6', 'Komotini', '1',
 'Georgia', '6994972419', 'Alexandros',
 'armed', 'A', 'JAY7947');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Athanasiadis', 'active',
 'Omirou 108', 'Komotini', '1',
 'Sofia', '6918855540', 'Ioannis',
 'unarmed', 'A', 'UGW2340');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Georgiou', 'active',
 'Vempo Sophias 25', 'Thessaloniki', '1',
 'Dimitra', '6978618680', 'Manolis',
 'armed', 'A', 'NEE8734');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Karalis', 'active',
 'Solonos 48', 'Athens', '1',
 'Eleni', '6990322008', 'Petros',
 'armed', 'A', 'FES2759');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Christou', 'active',
 'Solonos 108', 'Volos', '1',
 'Eirini', '6933259210', 'Stelios',
 'armed', 'A', 'UTS7952');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Papandreou 77', 'Thessaloniki', '1',
 'Georgia', '6974277035', 'Christos',
 'armed', 'A', 'KNU9072');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Papadopoulos', 'active',
 'Platonos 17', 'Serres', '1',
 'Ioanna', '6906831872', 'Vasileios',
 'armed', 'A', 'VWB2819');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Platonos 195', 'Volos', '1',
 'Ioanna', '6927645886', 'Manolis',
 'armed', 'A', 'LHH7759');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Platonos 29', 'Patra', '1',
 'Eirini', '6924578605', 'Alexandros',
 'armed', 'A', 'EWE7524');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Ioannou', 'active',
 'Omirou 70', 'Chania', '1',
 'Dimitra', '6903822117', 'Petros',
 'armed', 'A', 'WWY2917');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Mantzouranis', 'active',
 'Sokratous 165', 'Chania', '1',
 'Dimitra', '6941620740', 'Pavlos',
 'armed', 'A', 'TPJ8268');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Karalis', 'active',
 'Sokratous 58', 'Patra', '1',
 'Sofia', '6928008224', 'Manolis',
 'armed', 'A', 'LRI1502');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Christou', 'active',
 'Solonos 106', 'Patra', '1',
 'Anna', '6915546279', 'Christos',
 'armed', 'A', 'FXQ1889');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Mantzouranis', 'active',
 'Omirou 116', 'Heraklion', '1',
 'Maria', '6983521969', 'Stelios',
 'armed', 'A', 'AGK8204');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Ioannou', 'active',
 'Venizelou 194', 'Chania', '1',
 'Dimitra', '6962515084', 'Sotirios',
 'unarmed', 'A', 'QIZ6067');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Karaiskaki 78', 'Komotini', '1',
 'Eleni', '6959104263', 'Theodoros',
 'armed', 'A', 'XIH1000');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Athanasiadis', 'active',
 'Karaiskaki 85', 'Chania', '1',
 'Ioanna', '6918593116', 'Michail',
 'armed', 'A', 'CHC4232');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Lazaridis', 'active',
 'Platonos 70', 'Heraklion', '1',
 'Sofia', '6998820650', 'Christos',
 'armed', 'A', 'PKV1877');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Nikolaidis', 'active',
 'Karaiskaki 76', 'Komotini', '1',
 'Sofia', '6982847164', 'Pavlos',
 'armed', 'A', 'IJN8998');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Christou', 'active',
 'Solonos 47', 'Komotini', '1',
 'Katerina', '6955553197', 'Christos',
 'armed', 'A', 'VRW3488');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Spanos', 'active',
 'Omirou 43', 'Athens', '1',
 'Ioanna', '6920033806', 'Christos',
 'armed', 'A', 'XAO2985');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Perikleous 158', 'Serres', '1',
 'Eirini', '6927497357', 'Manolis',
 'armed', 'A', 'LBQ8380');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Panagiotou', 'active',
 'Platonos 21', 'Chania', '1',
 'Vasiliki', '6987012891', 'Konstantinos',
 'armed', 'A', 'JQT6788');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Lazaridis', 'active',
 'Solonos 138', 'Patra', '1',
 'Ioanna', '6934440391', 'Vasileios',
 'armed', 'A', 'KQP3544');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Sokratous 171', 'Volos', '1',
 'Maria', '6918815771', 'Stelios',
 'armed', 'A', 'BOF0574');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Petridis', 'active',
 'Sokratous 22', 'Volos', '1',
 'Georgia', '6992636338', 'Sotirios',
 'unarmed', 'A', 'WKT3822');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Solonos 41', 'Serres', '1',
 'Georgia', '6983269879', 'Georgios',
 'armed', 'A', 'OIT2710');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Petridis', 'active',
 'Karaiskaki 49', 'Kavala', '1',
 'Anna', '6925297467', 'Thanasis',
 'armed', 'A', 'FHK8725');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Kotsis', 'active',
 'Venizelou 5', 'Heraklion', '1',
 'Maria', '6978536420', 'Anastasios',
 'armed', 'A', 'XPK1980');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Karalis', 'active',
 'Venizelou 55', 'Komotini', '1',
 'Ioanna', '6956605835', 'Michail',
 'armed', 'A', 'WHD0201');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Petridis', 'active',
 'Venizelou 80', 'Komotini', '1',
 'Anna', '6984352835', 'Ioannis',
 'armed', 'A', 'KRS4707');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Nikolaidis', 'active',
 'Omirou 15', 'Thessaloniki', '1',
 'Sofia', '6971442631', 'Anastasios',
 'armed', 'A', 'PNL3779');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Panagiotou', 'active',
 'Solonos 106', 'Chania', '1',
 'Ioanna', '6900061183', 'Sotirios',
 'armed', 'A', 'DLH3647');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Sokratous 72', 'Serres', '1',
 'Dimitra', '6919913430', 'Thanasis',
 'unarmed', 'A', 'HXD4975');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Athanasiadis', 'active',
 'Platonos 169', 'Kavala', '1',
 'Georgia', '6900334006', 'Konstantinos',
 'armed', 'A', 'QJM6321');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Kotsis', 'active',
 'Perikleous 131', 'Athens', '1',
 'Vasiliki', '6999416973', 'Leonidas',
 'armed', 'A', 'MUF8927');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Athanasiadis', 'active',
 'Venizelou 81', 'Athens', '1',
 'Vasiliki', '6957850520', 'Michail',
 'armed', 'A', 'HQM8030');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Papadopoulos', 'active',
 'Venizelou 57', 'Chania', '1',
 'Eleni', '6994472947', 'Michail',
 'armed', 'A', 'HDE4649');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Zafeiris', 'active',
 'Karaiskaki 57', 'Athens', '1',
 'Anna', '6904581225', 'Sotirios',
 'armed', 'A', 'LAK6669');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Vempo Sophias 51', 'Volos', '1',
 'Dimitra', '6934329453', 'Pavlos',
 'armed', 'A', 'KZZ5265');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Karalis', 'active',
 'Venizelou 11', 'Chania', '1',
 'Vasiliki', '6964571015', 'Stelios',
 'armed', 'A', 'LSV0853');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Theodorakis', 'active',
 'Papandreou 135', 'Volos', '1',
 'Katerina', '6965748580', 'Ioannis',
 'armed', 'A', 'XXD3156');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Georgiou', 'active',
 'Platonos 2', 'Athens', '1',
 'Eleni', '6980674020', 'Michail',
 'armed', 'A', 'EZK8321');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Nikolaidis', 'active',
 'Papandreou 93', 'Thessaloniki', '1',
 'Dimitra', '6967111884', 'Anastasios',
 'armed', 'A', 'XDJ2456');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Spanos', 'active',
 'Perikleous 22', 'Heraklion', '1',
 'Georgia', '6960020646', 'Konstantinos',
 'armed', 'A', 'UOB6782');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Georgiou', 'active',
 'Karaiskaki 110', 'Volos', '1',
 'Ioanna', '6964744874', 'Konstantinos',
 'unarmed', 'A', 'SXU3041');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Petridis', 'active',
 'Papandreou 58', 'Komotini', '1',
 'Anna', '6979558563', 'Manolis',
 'armed', 'A', 'ONU4345');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Athanasiadis', 'active',
 'Platonos 75', 'Serres', '1',
 'Anna', '6966591315', 'Anastasios',
 'armed', 'A', 'PLM8803');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Papadopoulos', 'active',
 'Papandreou 176', 'Thessaloniki', '1',
 'Vasiliki', '6928800735', 'Georgios',
 'armed', 'A', 'FDN3219');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Alexopoulos', 'active',
 'Solonos 174', 'Thessaloniki', '1',
 'Katerina', '6940594532', 'Ioannis',
 'armed', 'A', 'DNH0442');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Karalis', 'active',
 'Perikleous 21', 'Athens', '1',
 'Vasiliki', '6920837085', 'Stelios',
 'armed', 'A', 'CUH2080');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Theodorakis', 'active',
 'Omirou 117', 'Heraklion', '1',
 'Vasiliki', '6963344563', 'Konstantinos',
 'armed', 'A', 'JRZ9319');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Nikolaidis', 'active',
 'Solonos 153', 'Serres', '1',
 'Eirini', '6924974887', 'Christos',
 'armed', 'A', 'QHE6159');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Nikolaidis', 'active',
 'Solonos 159', 'Patra', '1',
 'Eirini', '6944306539', 'Leonidas',
 'armed', 'A', 'YCG6041');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Omirou 123', 'Larisa', '1',
 'Anna', '6942592546', 'Alexandros',
 'armed', 'A', 'BFR3421');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Theodorakis', 'active',
 'Papandreou 193', 'Kavala', '1',
 'Eleni', '6988792652', 'Stelios',
 'armed', 'A', 'NOC7837');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Spanos', 'active',
 'Sokratous 186', 'Thessaloniki', '1',
 'Maria', '6945960066', 'Pavlos',
 'armed', 'A', 'JBR1119');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Ioannou', 'active',
 'Vempo Sophias 132', 'Heraklion', '1',
 'Eirini', '6991054759', 'Thanasis',
 'armed', 'A', 'AIS7543');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Petridis', 'active',
 'Sokratous 135', 'Komotini', '1',
 'Dimitra', '6926789791', 'Konstantinos',
 'armed', 'A', 'WWM9950');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Mantzouranis', 'active',
 'Solonos 196', 'Thessaloniki', '1',
 'Katerina', '6982042348', 'Michail',
 'unarmed', 'A', 'GKE7533');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Alexopoulos', 'active',
 'Papandreou 179', 'Patra', '1',
 'Eirini', '6931636560', 'Pavlos',
 'armed', 'A', 'NHX4477');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Karalis', 'active',
 'Papandreou 173', 'Serres', '1',
 'Dimitra', '6917691411', 'Christos',
 'armed', 'A', 'DAR7087');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Vempo Sophias 144', 'Komotini', '1',
 'Georgia', '6923132363', 'Sotirios',
 'armed', 'A', 'GDG9151');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Georgiou', 'active',
 'Venizelou 141', 'Kavala', '1',
 'Anna', '6976238808', 'Leonidas',
 'armed', 'A', 'VTK9051');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Zafeiris', 'active',
 'Vempo Sophias 37', 'Komotini', '1',
 'Anna', '6913013220', 'Leonidas',
 'armed', 'A', 'JMI0765');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Karaiskaki 76', 'Patra', '1',
 'Georgia', '6940722965', 'Stelios',
 'armed', 'A', 'FXW9743');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Zafeiris', 'active',
 'Karaiskaki 85', 'Larisa', '1',
 'Anna', '6917205102', 'Petros',
 'armed', 'A', 'YUI9178');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Alexopoulos', 'active',
 'Sokratous 44', 'Thessaloniki', '1',
 'Katerina', '6978151559', 'Christos',
 'armed', 'A', 'CIM1257');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Platonos 4', 'Larisa', '1',
 'Katerina', '6937254802', 'Manolis',
 'armed', 'A', 'LOW8788');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Athanasiadis', 'active',
 'Sokratous 48', 'Serres', '1',
 'Eirini', '6970748883', 'Christos',
 'armed', 'A', 'DHG5318');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Petridis', 'active',
 'Venizelou 188', 'Serres', '1',
 'Sofia', '6902803771', 'Ioannis',
 'armed', 'A', 'QMQ4658');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Papandreou 187', 'Kavala', '1',
 'Ioanna', '6978403462', 'Thanasis',
 'armed', 'A', 'TKC4926');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Lazaridis', 'active',
 'Platonos 110', 'Heraklion', '1',
 'Katerina', '6954777270', 'Pavlos',
 'armed', 'A', 'DXG8201');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Athanasiadis', 'active',
 'Vempo Sophias 165', 'Komotini', '1',
 'Anna', '6956704003', 'Stelios',
 'armed', 'A', 'TDX3144');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Ioannou', 'active',
 'Omirou 168', 'Volos', '1',
 'Eleni', '6909572137', 'Stelios',
 'armed', 'A', 'KCT8133');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Kotsis', 'active',
 'Vempo Sophias 197', 'Kavala', '1',
 'Eleni', '6943860052', 'Stelios',
 'armed', 'A', 'ZUY9836');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Christou', 'active',
 'Venizelou 77', 'Thessaloniki', '1',
 'Ioanna', '6987708573', 'Pavlos',
 'armed', 'A', 'PLV8128');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Georgiou', 'active',
 'Omirou 103', 'Serres', '1',
 'Anna', '6902718516', 'Vasileios',
 'armed', 'A', 'SUC7324');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Karalis', 'active',
 'Karaiskaki 170', 'Serres', '1',
 'Eirini', '6929018313', 'Pavlos',
 'armed', 'A', 'GUA8163');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Christou', 'active',
 'Sokratous 184', 'Volos', '1',
 'Maria', '6945840081', 'Konstantinos',
 'armed', 'A', 'NBY0422');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Zafeiris', 'active',
 'Sokratous 5', 'Thessaloniki', '1',
 'Maria', '6926000358', 'Christos',
 'armed', 'A', 'TZY4781');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Papadopoulos', 'active',
 'Platonos 59', 'Thessaloniki', '1',
 'Sofia', '6923300097', 'Sotirios',
 'armed', 'A', 'TGM6966');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Petridis', 'active',
 'Sokratous 38', 'Chania', '1',
 'Eirini', '6992949013', 'Leonidas',
 'unarmed', 'A', 'TRV8755');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Alexopoulos', 'active',
 'Karaiskaki 144', 'Thessaloniki', '1',
 'Anna', '6925339255', 'Leonidas',
 'armed', 'A', 'SXF5414');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Petridis', 'active',
 'Papandreou 44', 'Serres', '1',
 'Sofia', '6917328004', 'Ioannis',
 'armed', 'A', 'JIT3200');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Athanasiadis', 'active',
 'Perikleous 64', 'Volos', '1',
 'Sofia', '6945618622', 'Manolis',
 'armed', 'A', 'XQT6838');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Karalis', 'active',
 'Vempo Sophias 153', 'Komotini', '1',
 'Ioanna', '6959395034', 'Sotirios',
 'armed', 'A', 'IWQ1510');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Christou', 'active',
 'Sokratous 95', 'Larisa', '1',
 'Vasiliki', '6919179254', 'Pavlos',
 'armed', 'A', 'IQT1575');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Lazaridis', 'active',
 'Papandreou 168', 'Larisa', '1',
 'Eleni', '6917947113', 'Vasileios',
 'unarmed', 'A', 'FGY6645');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Kotsis', 'active',
 'Venizelou 80', 'Komotini', '1',
 'Sofia', '6946839162', 'Ioannis',
 'armed', 'A', 'NAQ6541');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Zafeiris', 'active',
 'Perikleous 8', 'Athens', '1',
 'Eleni', '6959417615', 'Stelios',
 'armed', 'A', 'HQN6535');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Lazaridis', 'active',
 'Karaiskaki 46', 'Volos', '1',
 'Georgia', '6942585863', 'Thanasis',
 'unarmed', 'A', 'LIW5116');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Lazaridis', 'active',
 'Perikleous 106', 'Thessaloniki', '1',
 'Dimitra', '6944191946', 'Konstantinos',
 'armed', 'A', 'HCJ8146');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Nikolaidis', 'active',
 'Sokratous 56', 'Kavala', '1',
 'Anna', '6916844054', 'Pavlos',
 'armed', 'A', 'MCI0723');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Mantzouranis', 'active',
 'Solonos 42', 'Serres', '1',
 'Eleni', '6976027803', 'Stelios',
 'unarmed', 'A', 'WUR7589');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Zafeiris', 'active',
 'Vempo Sophias 182', 'Heraklion', '1',
 'Ioanna', '6976426124', 'Michail',
 'armed', 'A', 'GBC3006');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Solonos 35', 'Komotini', '1',
 'Ioanna', '6963110607', 'Anastasios',
 'armed', 'A', 'YOQ3557');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Christou', 'active',
 'Papandreou 71', 'Chania', '1',
 'Eirini', '6977694595', 'Ioannis',
 'armed', 'A', 'RNG8896');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Dedes', 'active',
 'Omirou 92', 'Patra', '1',
 'Vasiliki', '6925465712', 'Stelios',
 'armed', 'A', 'OFW4971');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Spanos', 'active',
 'Platonos 12', 'Volos', '1',
 'Dimitra', '6991775113', 'Ioannis',
 'armed', 'A', 'HBB3809');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Mantzouranis', 'active',
 'Omirou 2', 'Chania', '1',
 'Eleni', '6937136881', 'Michail',
 'armed', 'A', 'KVZ7640');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Petridis', 'active',
 'Venizelou 156', 'Larisa', '1',
 'Anna', '6956136016', 'Petros',
 'armed', 'A', 'GGU3520');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Spanos', 'active',
 'Sokratous 82', 'Larisa', '1',
 'Dimitra', '6943662344', 'Alexandros',
 'armed', 'A', 'AAF7209');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Lazaridis', 'active',
 'Vempo Sophias 169', 'Larisa', '1',
 'Vasiliki', '6912990114', 'Christos',
 'armed', 'A', 'RBG6869');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Kotsis', 'active',
 'Solonos 139', 'Komotini', '1',
 'Georgia', '6981116110', 'Alexandros',
 'armed', 'A', 'AZQ6817');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Mantzouranis', 'active',
 'Karaiskaki 108', 'Kavala', '1',
 'Vasiliki', '6965416646', 'Konstantinos',
 'armed', 'A', 'LFD8394');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Zafeiris', 'active',
 'Platonos 31', 'Heraklion', '1',
 'Georgia', '6924431959', 'Konstantinos',
 'armed', 'A', 'BCU8144');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Lazaridis', 'active',
 'Karaiskaki 18', 'Komotini', '1',
 'Maria', '6956244861', 'Christos',
 'armed', 'A', 'OST4752');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Theodorakis', 'active',
 'Platonos 22', 'Kavala', '1',
 'Maria', '6905809249', 'Alexandros',
 'armed', 'A', 'LQT0892');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Papadopoulos', 'active',
 'Papandreou 177', 'Chania', '1',
 'Dimitra', '6951928579', 'Georgios',
 'armed', 'A', 'IQQ3280');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Panagiotou', 'active',
 'Perikleous 62', 'Komotini', '1',
 'Dimitra', '6976455900', 'Petros',
 'armed', 'A', 'HZW2356');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Petridis', 'active',
 'Karaiskaki 81', 'Patra', '1',
 'Dimitra', '6902550856', 'Georgios',
 'armed', 'A', 'MVM4631');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Athanasiadis', 'active',
 'Venizelou 7', 'Kavala', '1',
 'Eleni', '6928795331', 'Ioannis',
 'armed', 'A', 'KOA3719');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Zafeiris', 'active',
 'Papandreou 162', 'Heraklion', '1',
 'Vasiliki', '6918279445', 'Petros',
 'armed', 'A', 'FWI1567');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Papandreou 106', 'Patra', '1',
 'Ioanna', '6908074629', 'Manolis',
 'armed', 'A', 'YLV8640');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Theodorakis', 'active',
 'Papandreou 139', 'Komotini', '1',
 'Vasiliki', '6932322998', 'Ioannis',
 'armed', 'A', 'OHT2500');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Panagiotou', 'active',
 'Venizelou 93', 'Chania', '1',
 'Georgia', '6982496340', 'Stelios',
 'armed', 'A', 'LBG7183');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Perikleous 36', 'Larisa', '1',
 'Eleni', '6960588526', 'Konstantinos',
 'armed', 'A', 'BNG8833');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Nikolaidis', 'active',
 'Perikleous 198', 'Patra', '1',
 'Dimitra', '6943652762', 'Anastasios',
 'armed', 'A', 'KAK5638');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Georgiou', 'active',
 'Solonos 141', 'Serres', '1',
 'Maria', '6926291395', 'Stelios',
 'armed', 'A', 'UQM0757');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Ioannou', 'active',
 'Platonos 198', 'Patra', '1',
 'Sofia', '6985615571', 'Leonidas',
 'armed', 'A', 'HCU2624');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Kotsis', 'active',
 'Platonos 104', 'Serres', '1',
 'Eleni', '6923596902', 'Theodoros',
 'armed', 'A', 'DKV2213');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Christou', 'active',
 'Papandreou 89', 'Chania', '1',
 'Georgia', '6995665426', 'Stelios',
 'armed', 'A', 'BCH6433');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Nikolaidis', 'active',
 'Vempo Sophias 3', 'Thessaloniki', '1',
 'Eleni', '6954325355', 'Konstantinos',
 'unarmed', 'A', 'AAV6469');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Georgiou', 'active',
 'Sokratous 55', 'Chania', '1',
 'Vasiliki', '6935798647', 'Christos',
 'unarmed', 'A', 'YZL9632');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Lazaridis', 'active',
 'Perikleous 81', 'Volos', '1',
 'Georgia', '6954547083', 'Alexandros',
 'armed', 'A', 'SCQ9366');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Ioannou', 'active',
 'Karaiskaki 197', 'Athens', '1',
 'Eirini', '6914785872', 'Alexandros',
 'unarmed', 'A', 'ADJ5770');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Mantzouranis', 'active',
 'Sokratous 69', 'Patra', '1',
 'Maria', '6962135509', 'Konstantinos',
 'armed', 'A', 'YOW9776');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Petridis', 'active',
 'Venizelou 177', 'Athens', '1',
 'Anna', '6927065680', 'Manolis',
 'armed', 'A', 'GZE4417');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Kotsis', 'active',
 'Venizelou 87', 'Chania', '1',
 'Katerina', '6985692957', 'Manolis',
 'armed', 'A', 'JVN4641');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Lazaridis', 'active',
 'Venizelou 80', 'Komotini', '1',
 'Dimitra', '6904961770', 'Thanasis',
 'armed', 'A', 'NDC5338');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Nikolaidis', 'active',
 'Solonos 117', 'Chania', '1',
 'Anna', '6973476679', 'Alexandros',
 'armed', 'A', 'OEJ0459');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Theodorakis', 'active',
 'Perikleous 191', 'Komotini', '1',
 'Georgia', '6926498272', 'Pavlos',
 'armed', 'A', 'SOI2429');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Mantzouranis', 'active',
 'Perikleous 2', 'Patra', '1',
 'Anna', '6961779438', 'Leonidas',
 'armed', 'A', 'YCO0012');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Georgiou', 'active',
 'Perikleous 137', 'Patra', '1',
 'Eirini', '6971940303', 'Thanasis',
 'armed', 'A', 'VUZ6221');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Georgiou', 'active',
 'Venizelou 170', 'Athens', '1',
 'Katerina', '6954939313', 'Anastasios',
 'armed', 'A', 'SGI6155');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Karalis', 'active',
 'Venizelou 28', 'Heraklion', '1',
 'Eirini', '6976257845', 'Thanasis',
 'unarmed', 'A', 'JCD9372');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Nikolaidis', 'active',
 'Omirou 87', 'Volos', '1',
 'Eleni', '6989483872', 'Stelios',
 'armed', 'A', 'AJD0358');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Venizelou 17', 'Kavala', '1',
 'Ioanna', '6911956341', 'Ioannis',
 'armed', 'A', 'QNX2276');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Spanos', 'active',
 'Omirou 15', 'Heraklion', '1',
 'Sofia', '6923479670', 'Christos',
 'armed', 'A', 'BDX7873');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Perikleous 49', 'Heraklion', '1',
 'Dimitra', '6916509666', 'Vasileios',
 'armed', 'A', 'NOO8604');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Dedes', 'active',
 'Solonos 126', 'Chania', '1',
 'Ioanna', '6924407889', 'Ioannis',
 'unarmed', 'A', 'VBX3641');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Athanasiadis', 'active',
 'Venizelou 16', 'Chania', '1',
 'Georgia', '6980479723', 'Anastasios',
 'armed', 'A', 'XWY3171');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Panagiotou', 'active',
 'Omirou 189', 'Komotini', '1',
 'Georgia', '6934825574', 'Konstantinos',
 'armed', 'A', 'VXS9406');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Kotsis', 'active',
 'Platonos 191', 'Kavala', '1',
 'Georgia', '6903927507', 'Alexandros',
 'armed', 'A', 'MLZ7198');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Zafeiris', 'active',
 'Karaiskaki 58', 'Athens', '1',
 'Vasiliki', '6997166259', 'Michail',
 'armed', 'A', 'ZXY5308');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Lazaridis', 'active',
 'Solonos 58', 'Patra', '1',
 'Eirini', '6926417714', 'Stelios',
 'armed', 'A', 'OFL8884');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Lazaridis', 'active',
 'Karaiskaki 110', 'Athens', '1',
 'Eleni', '6978075275', 'Stelios',
 'unarmed', 'A', 'UBA2578');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Zafeiris', 'active',
 'Venizelou 161', 'Patra', '1',
 'Vasiliki', '6919212645', 'Michail',
 'armed', 'A', 'SXR0557');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Petridis', 'active',
 'Platonos 152', 'Heraklion', '1',
 'Sofia', '6967208891', 'Michail',
 'armed', 'A', 'TSU7724');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Papadopoulos', 'active',
 'Karaiskaki 133', 'Heraklion', '1',
 'Sofia', '6915735312', 'Ioannis',
 'armed', 'A', 'DFL8245');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Nikolaidis', 'active',
 'Perikleous 96', 'Thessaloniki', '1',
 'Sofia', '6986062784', 'Pavlos',
 'armed', 'A', 'YTY7026');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Karalis', 'active',
 'Venizelou 29', 'Chania', '1',
 'Katerina', '6914524877', 'Vasileios',
 'armed', 'A', 'AMP0836');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Papadopoulos', 'active',
 'Perikleous 14', 'Komotini', '1',
 'Dimitra', '6945420264', 'Ioannis',
 'armed', 'A', 'IVR8557');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Platonos 62', 'Kavala', '1',
 'Anna', '6993161763', 'Theodoros',
 'armed', 'A', 'UZD3044');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Ioannou', 'active',
 'Omirou 77', 'Thessaloniki', '1',
 'Dimitra', '6957859904', 'Michail',
 'unarmed', 'A', 'YXY7112');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Venizelou 179', 'Larisa', '1',
 'Ioanna', '6949866837', 'Vasileios',
 'armed', 'A', 'QUM8180');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Alexopoulos', 'active',
 'Perikleous 137', 'Kavala', '1',
 'Anna', '6965550443', 'Sotirios',
 'armed', 'A', 'NIA1283');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Papandreou 1', 'Athens', '1',
 'Eleni', '6962051737', 'Thanasis',
 'armed', 'A', 'UYS4013');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Panagiotou', 'active',
 'Platonos 56', 'Chania', '1',
 'Anna', '6970154985', 'Konstantinos',
 'armed', 'A', 'ETR8824');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Alexopoulos', 'active',
 'Vempo Sophias 4', 'Komotini', '1',
 'Sofia', '6945434904', 'Michail',
 'unarmed', 'A', 'FAZ3227');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Alexopoulos', 'active',
 'Solonos 10', 'Larisa', '1',
 'Ioanna', '6930856448', 'Theodoros',
 'armed', 'A', 'CNZ9893');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Zafeiris', 'active',
 'Vempo Sophias 144', 'Larisa', '1',
 'Katerina', '6958781764', 'Christos',
 'armed', 'A', 'NJL1256');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Spanos', 'active',
 'Papandreou 5', 'Serres', '1',
 'Eleni', '6986295310', 'Michail',
 'armed', 'A', 'CSV1718');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Mantzouranis', 'active',
 'Vempo Sophias 139', 'Thessaloniki', '1',
 'Anna', '6970123969', 'Theodoros',
 'armed', 'A', 'WQQ9966');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Nikolaidis', 'active',
 'Venizelou 19', 'Larisa', '1',
 'Katerina', '6965764336', 'Ioannis',
 'armed', 'A', 'GGE3036');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Theodorakis', 'active',
 'Venizelou 189', 'Patra', '1',
 'Sofia', '6975797565', 'Georgios',
 'armed', 'A', 'VPG4691');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Kotsis', 'active',
 'Venizelou 47', 'Thessaloniki', '1',
 'Georgia', '6987065986', 'Theodoros',
 'armed', 'A', 'ZDR5122');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Lazaridis', 'active',
 'Vempo Sophias 96', 'Patra', '1',
 'Maria', '6972494292', 'Vasileios',
 'armed', 'A', 'CGT4275');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Papadopoulos', 'active',
 'Venizelou 4', 'Larisa', '1',
 'Maria', '6958203006', 'Petros',
 'armed', 'A', 'EHT7559');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Panagiotou', 'active',
 'Solonos 30', 'Heraklion', '1',
 'Sofia', '6932423887', 'Anastasios',
 'armed', 'A', 'MBX5233');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Dedes', 'active',
 'Karaiskaki 5', 'Serres', '1',
 'Sofia', '6973701628', 'Konstantinos',
 'armed', 'A', 'QDU3050');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Alexopoulos', 'active',
 'Perikleous 79', 'Volos', '1',
 'Maria', '6945708434', 'Manolis',
 'unarmed', 'A', 'AHA6035');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Sokratous 70', 'Thessaloniki', '1',
 'Vasiliki', '6904160503', 'Stelios',
 'armed', 'A', 'XHB5329');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Theodorakis', 'active',
 'Vempo Sophias 47', 'Patra', '1',
 'Vasiliki', '6955048537', 'Stelios',
 'armed', 'A', 'VWG3482');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Zafeiris', 'active',
 'Vempo Sophias 19', 'Larisa', '1',
 'Eleni', '6985441152', 'Vasileios',
 'armed', 'A', 'BNW1728');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Sokratous 75', 'Heraklion', '1',
 'Eirini', '6924277676', 'Anastasios',
 'armed', 'A', 'HKB8686');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Georgiou', 'active',
 'Omirou 22', 'Chania', '1',
 'Sofia', '6986638788', 'Thanasis',
 'unarmed', 'A', 'QEF9090');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Panagiotou', 'active',
 'Sokratous 115', 'Komotini', '1',
 'Vasiliki', '6941676069', 'Thanasis',
 'armed', 'A', 'EIE7930');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Theodorakis', 'active',
 'Perikleous 75', 'Patra', '1',
 'Eleni', '6962575816', 'Sotirios',
 'armed', 'A', 'VNE3587');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Kotsis', 'active',
 'Venizelou 58', 'Kavala', '1',
 'Vasiliki', '6966969761', 'Manolis',
 'armed', 'A', 'VYV2606');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Athanasiadis', 'active',
 'Solonos 47', 'Larisa', '1',
 'Katerina', '6927623331', 'Pavlos',
 'armed', 'A', 'JKZ3774');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Petridis', 'active',
 'Omirou 32', 'Athens', '1',
 'Dimitra', '6969534994', 'Pavlos',
 'armed', 'A', 'WHG4894');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Dedes', 'active',
 'Vempo Sophias 139', 'Thessaloniki', '1',
 'Ioanna', '6961207682', 'Manolis',
 'armed', 'A', 'OHK0928');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Platonos 41', 'Patra', '1',
 'Katerina', '6913312989', 'Michail',
 'armed', 'A', 'AKP1881');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Nikolaidis', 'active',
 'Platonos 4', 'Athens', '1',
 'Katerina', '6956854119', 'Alexandros',
 'armed', 'A', 'MVO0478');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Nikolaidis', 'active',
 'Sokratous 153', 'Thessaloniki', '1',
 'Maria', '6960838020', 'Anastasios',
 'unarmed', 'A', 'QHR1045');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Theodorakis', 'active',
 'Platonos 23', 'Thessaloniki', '1',
 'Eirini', '6924354447', 'Konstantinos',
 'armed', 'A', 'FSH5837');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Alexopoulos', 'active',
 'Perikleous 128', 'Komotini', '1',
 'Ioanna', '6911073176', 'Vasileios',
 'unarmed', 'A', 'HUC5805');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Ioannou', 'active',
 'Vempo Sophias 198', 'Kavala', '1',
 'Ioanna', '6997940537', 'Petros',
 'unarmed', 'A', 'MTY7601');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Panagiotou', 'active',
 'Karaiskaki 83', 'Thessaloniki', '1',
 'Anna', '6949027259', 'Alexandros',
 'armed', 'A', 'AGH4010');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Athanasiadis', 'active',
 'Solonos 21', 'Komotini', '1',
 'Maria', '6945911037', 'Michail',
 'unarmed', 'A', 'CCP9118');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Nikolaidis', 'active',
 'Omirou 22', 'Patra', '1',
 'Anna', '6953695370', 'Konstantinos',
 'armed', 'A', 'JAW7858');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Karalis', 'active',
 'Sokratous 154', 'Komotini', '1',
 'Dimitra', '6906672611', 'Georgios',
 'armed', 'A', 'AQC7663');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Panagiotou', 'active',
 'Papandreou 93', 'Patra', '1',
 'Georgia', '6962611560', 'Pavlos',
 'armed', 'A', 'DPP4102');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Spanos', 'active',
 'Platonos 188', 'Athens', '1',
 'Georgia', '6959878181', 'Konstantinos',
 'armed', 'A', 'AYQ4795');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Papadopoulos', 'active',
 'Omirou 165', 'Chania', '1',
 'Anna', '6923881138', 'Pavlos',
 'armed', 'A', 'IWF2162');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Panagiotou', 'active',
 'Karaiskaki 1', 'Athens', '1',
 'Katerina', '6952385294', 'Michail',
 'armed', 'A', 'FYU7591');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Ioannou', 'active',
 'Karaiskaki 122', 'Komotini', '1',
 'Vasiliki', '6987819436', 'Christos',
 'armed', 'A', 'GTT4683');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Mantzouranis', 'active',
 'Sokratous 153', 'Larisa', '1',
 'Georgia', '6999122665', 'Ioannis',
 'armed', 'A', 'ETZ6496');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Alexopoulos', 'active',
 'Vempo Sophias 54', 'Chania', '1',
 'Anna', '6941409033', 'Stelios',
 'armed', 'A', 'FGY9278');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Karalis', 'active',
 'Solonos 134', 'Komotini', '1',
 'Eirini', '6913902516', 'Christos',
 'armed', 'A', 'LNQ7819');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Christou', 'active',
 'Venizelou 143', 'Komotini', '1',
 'Eleni', '6977860938', 'Konstantinos',
 'armed', 'A', 'ZUO8095');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Mantzouranis', 'active',
 'Vempo Sophias 191', 'Komotini', '1',
 'Sofia', '6999032035', 'Thanasis',
 'armed', 'A', 'XDA1057');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Alexopoulos', 'active',
 'Platonos 53', 'Heraklion', '1',
 'Sofia', '6904274602', 'Ioannis',
 'armed', 'A', 'DWD0838');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Sokratous 64', 'Athens', '1',
 'Sofia', '6919649767', 'Alexandros',
 'armed', 'A', 'OBL9544');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Ioannou', 'active',
 'Omirou 187', 'Kavala', '1',
 'Anna', '6900302425', 'Vasileios',
 'unarmed', 'A', 'BHA5002');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Christou', 'active',
 'Sokratous 188', 'Kavala', '1',
 'Katerina', '6989810528', 'Ioannis',
 'unarmed', 'A', 'WQG2967');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Sokratous 68', 'Patra', '1',
 'Dimitra', '6904367290', 'Pavlos',
 'armed', 'A', 'MVH3309');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Theodorakis', 'active',
 'Venizelou 1', 'Volos', '1',
 'Ioanna', '6992858931', 'Christos',
 'armed', 'A', 'DFU1946');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Petridis', 'active',
 'Venizelou 10', 'Patra', '1',
 'Dimitra', '6907290348', 'Georgios',
 'armed', 'A', 'MLZ6750');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Christou', 'active',
 'Solonos 51', 'Serres', '1',
 'Vasiliki', '6923902263', 'Pavlos',
 'armed', 'A', 'YWH4716');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Alexopoulos', 'active',
 'Solonos 109', 'Patra', '1',
 'Georgia', '6973503088', 'Leonidas',
 'armed', 'A', 'EYE9965');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Panagiotou', 'active',
 'Omirou 112', 'Patra', '1',
 'Georgia', '6979524393', 'Petros',
 'armed', 'A', 'LRI9151');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Zafeiris', 'active',
 'Papandreou 166', 'Chania', '1',
 'Eirini', '6960282357', 'Christos',
 'unarmed', 'A', 'OBD9315');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Petridis', 'active',
 'Venizelou 173', 'Thessaloniki', '1',
 'Vasiliki', '6974230238', 'Sotirios',
 'armed', 'A', 'ODR8592');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Vempo Sophias 92', 'Komotini', '1',
 'Sofia', '6949310763', 'Vasileios',
 'armed', 'A', 'OFT2398');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Alexopoulos', 'active',
 'Venizelou 71', 'Larisa', '1',
 'Georgia', '6932616777', 'Alexandros',
 'unarmed', 'A', 'DOB4669');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Theodorakis', 'active',
 'Vempo Sophias 121', 'Serres', '1',
 'Georgia', '6929772546', 'Leonidas',
 'armed', 'A', 'UKL8428');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Alexopoulos', 'active',
 'Sokratous 181', 'Komotini', '1',
 'Sofia', '6977570242', 'Theodoros',
 'armed', 'A', 'QGE5213');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Panagiotou', 'active',
 'Platonos 53', 'Thessaloniki', '1',
 'Vasiliki', '6963182182', 'Anastasios',
 'armed', 'A', 'SIU4969');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Venizelou 26', 'Kavala', '1',
 'Vasiliki', '6922380462', 'Alexandros',
 'armed', 'A', 'RNH2186');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Nikolaidis', 'active',
 'Omirou 61', 'Athens', '1',
 'Georgia', '6999597126', 'Pavlos',
 'armed', 'A', 'UUZ6721');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Kotsis', 'active',
 'Perikleous 102', 'Komotini', '1',
 'Maria', '6942512799', 'Pavlos',
 'armed', 'A', 'EMA2729');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Karalis', 'active',
 'Omirou 165', 'Thessaloniki', '1',
 'Anna', '6951704248', 'Petros',
 'armed', 'A', 'CQG2001');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Georgiou', 'active',
 'Papandreou 2', 'Athens', '1',
 'Anna', '6921385237', 'Stelios',
 'armed', 'A', 'LUX7269');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Theodorakis', 'active',
 'Vempo Sophias 178', 'Thessaloniki', '1',
 'Katerina', '6917195538', 'Theodoros',
 'armed', 'A', 'UVW2934');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Panagiotou', 'active',
 'Karaiskaki 98', 'Volos', '1',
 'Anna', '6987937399', 'Leonidas',
 'armed', 'A', 'FXC5264');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Ioannou', 'active',
 'Vempo Sophias 63', 'Komotini', '1',
 'Sofia', '6971638685', 'Konstantinos',
 'armed', 'A', 'DBF1559');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Lazaridis', 'active',
 'Sokratous 34', 'Thessaloniki', '1',
 'Anna', '6938460624', 'Vasileios',
 'armed', 'A', 'HCI3592');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Papadopoulos', 'active',
 'Vempo Sophias 99', 'Serres', '1',
 'Eleni', '6958838784', 'Leonidas',
 'unarmed', 'A', 'CEZ0290');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Papadopoulos', 'active',
 'Omirou 47', 'Komotini', '1',
 'Eirini', '6954888267', 'Georgios',
 'armed', 'A', 'DSX5329');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Panagiotou', 'active',
 'Karaiskaki 168', 'Chania', '1',
 'Katerina', '6904661962', 'Leonidas',
 'armed', 'A', 'HGT3093');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Sokratous 53', 'Serres', '1',
 'Ioanna', '6900178264', 'Vasileios',
 'armed', 'A', 'EES2092');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Karalis', 'active',
 'Sokratous 108', 'Thessaloniki', '1',
 'Anna', '6971118723', 'Stelios',
 'armed', 'A', 'NSL3807');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Zafeiris', 'active',
 'Sokratous 114', 'Serres', '1',
 'Maria', '6946190561', 'Vasileios',
 'armed', 'A', 'YKG9785');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Lazaridis', 'active',
 'Perikleous 44', 'Patra', '1',
 'Ioanna', '6972260093', 'Stelios',
 'unarmed', 'A', 'DJF5591');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Zafeiris', 'active',
 'Sokratous 54', 'Larisa', '1',
 'Vasiliki', '6946421658', 'Leonidas',
 'armed', 'A', 'OAT1436');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Mantzouranis', 'active',
 'Sokratous 53', 'Komotini', '1',
 'Georgia', '6944476703', 'Georgios',
 'armed', 'A', 'FKI6043');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Petridis', 'active',
 'Venizelou 49', 'Athens', '1',
 'Eirini', '6915434091', 'Theodoros',
 'armed', 'A', 'FCP8538');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Vempo Sophias 11', 'Volos', '1',
 'Eirini', '6964229654', 'Georgios',
 'armed', 'A', 'DZE4610');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Karaiskaki 30', 'Volos', '1',
 'Maria', '6955797236', 'Alexandros',
 'armed', 'A', 'IEL1163');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Perikleous 45', 'Volos', '1',
 'Georgia', '6927585427', 'Vasileios',
 'armed', 'A', 'DDQ2314');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Christou', 'active',
 'Sokratous 181', 'Komotini', '1',
 'Ioanna', '6978134241', 'Leonidas',
 'armed', 'A', 'TNS3103');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Papadopoulos', 'active',
 'Venizelou 12', 'Komotini', '1',
 'Sofia', '6913362932', 'Michail',
 'armed', 'A', 'OYB8007');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Ioannou', 'active',
 'Papandreou 55', 'Larisa', '1',
 'Dimitra', '6952172792', 'Theodoros',
 'armed', 'A', 'XKF8031');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Sokratous 28', 'Komotini', '1',
 'Sofia', '6926615667', 'Christos',
 'armed', 'A', 'CEN4150');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Zafeiris', 'active',
 'Platonos 181', 'Komotini', '1',
 'Sofia', '6995891330', 'Petros',
 'armed', 'A', 'ULR7101');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Vempo Sophias 198', 'Athens', '1',
 'Eirini', '6970812226', 'Thanasis',
 'armed', 'A', 'XAG3348');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Athanasiadis', 'active',
 'Vempo Sophias 112', 'Heraklion', '1',
 'Georgia', '6979716844', 'Stelios',
 'armed', 'A', 'RMR0812');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Papadopoulos', 'active',
 'Solonos 30', 'Kavala', '1',
 'Georgia', '6971729048', 'Leonidas',
 'armed', 'A', 'UUH9898');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Lazaridis', 'active',
 'Sokratous 15', 'Chania', '1',
 'Vasiliki', '6925313957', 'Pavlos',
 'armed', 'A', 'AWL7071');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Nikolaidis', 'active',
 'Sokratous 143', 'Larisa', '1',
 'Ioanna', '6978496695', 'Thanasis',
 'unarmed', 'A', 'WAN7231');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Spanos', 'active',
 'Papandreou 120', 'Larisa', '1',
 'Maria', '6955174892', 'Christos',
 'armed', 'A', 'AGR9344');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Papadopoulos', 'active',
 'Perikleous 74', 'Patra', '1',
 'Katerina', '6945853192', 'Petros',
 'armed', 'A', 'UUL4580');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Vempo Sophias 77', 'Komotini', '1',
 'Ioanna', '6979422857', 'Petros',
 'armed', 'A', 'JAG9726');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Spanos', 'active',
 'Vempo Sophias 111', 'Komotini', '1',
 'Dimitra', '6914146900', 'Pavlos',
 'unarmed', 'A', 'IYL7235');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Theodorakis', 'active',
 'Karaiskaki 79', 'Thessaloniki', '1',
 'Katerina', '6917973114', 'Theodoros',
 'armed', 'A', 'EYX3688');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Georgiou', 'active',
 'Omirou 117', 'Thessaloniki', '1',
 'Sofia', '6951992423', 'Leonidas',
 'armed', 'A', 'PZM4856');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Kotsis', 'active',
 'Omirou 108', 'Patra', '1',
 'Katerina', '6905584080', 'Pavlos',
 'armed', 'A', 'IOS8416');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Papadopoulos', 'active',
 'Solonos 33', 'Komotini', '1',
 'Dimitra', '6940653871', 'Theodoros',
 'armed', 'A', 'XHT7417');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Dedes', 'active',
 'Omirou 169', 'Thessaloniki', '1',
 'Eleni', '6941868779', 'Anastasios',
 'armed', 'A', 'VWY9596');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Petridis', 'active',
 'Omirou 12', 'Patra', '1',
 'Katerina', '6914557986', 'Leonidas',
 'unarmed', 'A', 'GAA6821');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Georgiou', 'active',
 'Vempo Sophias 189', 'Komotini', '1',
 'Eirini', '6940664861', 'Stelios',
 'armed', 'A', 'UOF7303');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Ioannou', 'active',
 'Venizelou 108', 'Chania', '1',
 'Anna', '6954582630', 'Alexandros',
 'armed', 'A', 'RKG5841');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Zafeiris', 'active',
 'Venizelou 23', 'Patra', '1',
 'Eirini', '6915279175', 'Konstantinos',
 'armed', 'A', 'AIP0215');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Petridis', 'active',
 'Platonos 57', 'Komotini', '1',
 'Eleni', '6913526703', 'Theodoros',
 'armed', 'A', 'KRH5113');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Sokratous 162', 'Larisa', '1',
 'Anna', '6918703639', 'Christos',
 'armed', 'A', 'NUD4592');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Athanasiadis', 'active',
 'Karaiskaki 191', 'Larisa', '1',
 'Dimitra', '6968526254', 'Christos',
 'unarmed', 'A', 'OYX7078');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Christou', 'active',
 'Venizelou 137', 'Larisa', '1',
 'Eleni', '6948239626', 'Leonidas',
 'unarmed', 'A', 'DLK2832');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Karaiskaki 197', 'Heraklion', '1',
 'Dimitra', '6964256549', 'Pavlos',
 'armed', 'A', 'VYA6253');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Dedes', 'active',
 'Venizelou 191', 'Athens', '1',
 'Katerina', '6976438461', 'Michail',
 'armed', 'A', 'RXG0723');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Perikleous 100', 'Kavala', '1',
 'Katerina', '6907057731', 'Petros',
 'armed', 'A', 'RRC8902');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Panagiotou', 'active',
 'Perikleous 45', 'Kavala', '1',
 'Anna', '6963654451', 'Georgios',
 'armed', 'A', 'UPU8976');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Papadopoulos', 'active',
 'Omirou 139', 'Serres', '1',
 'Anna', '6914082266', 'Alexandros',
 'armed', 'A', 'EFT1739');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Athanasiadis', 'active',
 'Platonos 172', 'Thessaloniki', '1',
 'Maria', '6903228952', 'Stelios',
 'armed', 'A', 'XQX5219');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Mantzouranis', 'active',
 'Sokratous 134', 'Volos', '1',
 'Katerina', '6938763848', 'Ioannis',
 'unarmed', 'A', 'HAH0702');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Karalis', 'active',
 'Vempo Sophias 163', 'Kavala', '1',
 'Vasiliki', '6901305827', 'Vasileios',
 'armed', 'A', 'BXC5383');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Nikolaidis', 'active',
 'Papandreou 14', 'Chania', '1',
 'Maria', '6930036741', 'Ioannis',
 'armed', 'A', 'BSX3365');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Platonos 149', 'Serres', '1',
 'Sofia', '6947489334', 'Leonidas',
 'armed', 'A', 'FYB2501');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Athanasiadis', 'active',
 'Platonos 149', 'Athens', '1',
 'Maria', '6977925712', 'Sotirios',
 'armed', 'A', 'ITN1447');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Spanos', 'active',
 'Sokratous 12', 'Kavala', '1',
 'Eirini', '6967958273', 'Konstantinos',
 'unarmed', 'A', 'JAW3765');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Alexopoulos', 'active',
 'Sokratous 138', 'Chania', '1',
 'Katerina', '6973856980', 'Stelios',
 'armed', 'A', 'BWQ0648');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Spanos', 'active',
 'Solonos 158', 'Chania', '1',
 'Eleni', '6902379561', 'Georgios',
 'armed', 'A', 'KWW7667');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Dedes', 'active',
 'Solonos 162', 'Heraklion', '1',
 'Eleni', '6969679050', 'Stelios',
 'armed', 'A', 'DIZ5462');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Lazaridis', 'active',
 'Papandreou 56', 'Larisa', '1',
 'Sofia', '6907475517', 'Michail',
 'armed', 'A', 'KBJ8315');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Mantzouranis', 'active',
 'Vempo Sophias 160', 'Athens', '1',
 'Sofia', '6909801071', 'Ioannis',
 'armed', 'A', 'LVO2492');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Athanasiadis', 'active',
 'Sokratous 3', 'Volos', '1',
 'Sofia', '6942161992', 'Stelios',
 'unarmed', 'A', 'YSD5584');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Lazaridis', 'active',
 'Papandreou 19', 'Thessaloniki', '1',
 'Anna', '6991913569', 'Thanasis',
 'armed', 'A', 'SHY1149');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Ioannou', 'active',
 'Vempo Sophias 94', 'Serres', '1',
 'Georgia', '6936306446', 'Konstantinos',
 'armed', 'A', 'SJC7951');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Kotsis', 'active',
 'Omirou 145', 'Komotini', '1',
 'Ioanna', '6996908291', 'Manolis',
 'armed', 'A', 'IAZ6620');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Ioannou', 'active',
 'Platonos 171', 'Patra', '1',
 'Katerina', '6922276397', 'Pavlos',
 'armed', 'A', 'SVP4900');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Papadopoulos', 'active',
 'Omirou 162', 'Volos', '1',
 'Maria', '6920416436', 'Pavlos',
 'armed', 'A', 'ZCV4495');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Karalis', 'active',
 'Karaiskaki 59', 'Larisa', '1',
 'Vasiliki', '6976990608', 'Christos',
 'unarmed', 'A', 'NLQ5936');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Lazaridis', 'active',
 'Papandreou 129', 'Thessaloniki', '1',
 'Eleni', '6988206841', 'Georgios',
 'armed', 'A', 'XRK4830');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Kotsis', 'active',
 'Omirou 88', 'Kavala', '1',
 'Georgia', '6930299980', 'Sotirios',
 'armed', 'A', 'DKO4079');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Lazaridis', 'active',
 'Sokratous 71', 'Kavala', '1',
 'Dimitra', '6977324758', 'Vasileios',
 'armed', 'A', 'AST7427');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Ioannou', 'active',
 'Karaiskaki 40', 'Thessaloniki', '1',
 'Anna', '6995410639', 'Christos',
 'armed', 'A', 'JAS2319');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Vempo Sophias 51', 'Kavala', '1',
 'Dimitra', '6952698605', 'Vasileios',
 'armed', 'A', 'ZXB1235');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Mantzouranis', 'active',
 'Sokratous 2', 'Serres', '1',
 'Katerina', '6984372754', 'Christos',
 'armed', 'A', 'DCY4162');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Zafeiris', 'active',
 'Omirou 79', 'Serres', '1',
 'Ioanna', '6930365057', 'Pavlos',
 'armed', 'A', 'TYI7571');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Kotsis', 'active',
 'Venizelou 191', 'Kavala', '1',
 'Katerina', '6991045966', 'Leonidas',
 'armed', 'A', 'AGL6756');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Ioannou', 'active',
 'Omirou 71', 'Volos', '1',
 'Georgia', '6926920099', 'Theodoros',
 'armed', 'A', 'KUF5266');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Alexopoulos', 'active',
 'Venizelou 187', 'Chania', '1',
 'Anna', '6977481065', 'Thanasis',
 'armed', 'A', 'RMK8551');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Theodorakis', 'active',
 'Platonos 74', 'Heraklion', '1',
 'Maria', '6970562085', 'Stelios',
 'armed', 'A', 'EMD5464');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Christou', 'active',
 'Vempo Sophias 154', 'Athens', '1',
 'Georgia', '6921343919', 'Pavlos',
 'unarmed', 'A', 'SDC5259');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Ioannou', 'active',
 'Omirou 152', 'Heraklion', '1',
 'Eirini', '6934476885', 'Thanasis',
 'armed', 'A', 'ZVJ2939');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Panagiotou', 'active',
 'Karaiskaki 22', 'Patra', '1',
 'Dimitra', '6906965441', 'Leonidas',
 'armed', 'A', 'PID9242');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Athanasiadis', 'active',
 'Platonos 81', 'Komotini', '1',
 'Vasiliki', '6900320291', 'Thanasis',
 'armed', 'A', 'WZK7979');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Ioannou', 'active',
 'Vempo Sophias 125', 'Kavala', '1',
 'Eleni', '6999840141', 'Alexandros',
 'armed', 'A', 'SUF1666');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Spanos', 'active',
 'Karaiskaki 87', 'Thessaloniki', '1',
 'Anna', '6939671159', 'Michail',
 'armed', 'A', 'KUA4047');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Spanos', 'active',
 'Vempo Sophias 150', 'Serres', '1',
 'Eirini', '6912791970', 'Georgios',
 'armed', 'A', 'LYV1526');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Petridis', 'active',
 'Omirou 140', 'Patra', '1',
 'Eleni', '6961647834', 'Sotirios',
 'armed', 'A', 'SOQ1330');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Alexopoulos', 'active',
 'Venizelou 21', 'Komotini', '1',
 'Ioanna', '6901848569', 'Ioannis',
 'armed', 'A', 'RBB4335');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Georgiou', 'active',
 'Karaiskaki 12', 'Heraklion', '1',
 'Sofia', '6939058941', 'Manolis',
 'unarmed', 'A', 'QDV4335');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Theodorakis', 'active',
 'Solonos 40', 'Athens', '1',
 'Vasiliki', '6955297112', 'Pavlos',
 'armed', 'A', 'KDZ7687');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Athanasiadis', 'active',
 'Solonos 140', 'Komotini', '1',
 'Eirini', '6984686044', 'Anastasios',
 'armed', 'A', 'ENC4599');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Theodorakis', 'active',
 'Vempo Sophias 53', 'Volos', '1',
 'Katerina', '6908585518', 'Alexandros',
 'armed', 'A', 'TZY4380');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Ioannou', 'active',
 'Solonos 77', 'Larisa', '1',
 'Ioanna', '6907132132', 'Manolis',
 'armed', 'A', 'DWZ6729');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Kotsis', 'active',
 'Platonos 164', 'Volos', '1',
 'Dimitra', '6958553393', 'Theodoros',
 'armed', 'A', 'SHY7635');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Spanos', 'active',
 'Platonos 134', 'Heraklion', '1',
 'Eirini', '6950328810', 'Georgios',
 'armed', 'A', 'WBV1735');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Papadopoulos', 'active',
 'Vempo Sophias 176', 'Heraklion', '1',
 'Eirini', '6985453348', 'Michail',
 'unarmed', 'A', 'GVI8202');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Theodorakis', 'active',
 'Perikleous 199', 'Athens', '1',
 'Georgia', '6927217636', 'Thanasis',
 'armed', 'A', 'TPU2990');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Athanasiadis', 'active',
 'Platonos 73', 'Volos', '1',
 'Eirini', '6994119694', 'Christos',
 'armed', 'A', 'XQC3817');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Karalis', 'active',
 'Sokratous 114', 'Thessaloniki', '1',
 'Dimitra', '6996168087', 'Pavlos',
 'unarmed', 'A', 'LZI7640');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Alexopoulos', 'active',
 'Papandreou 129', 'Chania', '1',
 'Anna', '6927888868', 'Sotirios',
 'armed', 'A', 'DMX9589');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Lazaridis', 'active',
 'Solonos 107', 'Volos', '1',
 'Sofia', '6915732736', 'Alexandros',
 'armed', 'A', 'LIK7553');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Mantzouranis', 'active',
 'Sokratous 37', 'Athens', '1',
 'Maria', '6958069051', 'Leonidas',
 'armed', 'A', 'ZVR7707');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Lazaridis', 'active',
 'Sokratous 95', 'Heraklion', '1',
 'Anna', '6936411149', 'Michail',
 'armed', 'A', 'LWU8097');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Petridis', 'active',
 'Karaiskaki 19', 'Kavala', '1',
 'Eleni', '6992235017', 'Leonidas',
 'armed', 'A', 'HEW8970');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Solonos 112', 'Serres', '1',
 'Anna', '6968544362', 'Leonidas',
 'armed', 'A', 'SEL0463');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Theodorakis', 'active',
 'Omirou 37', 'Kavala', '1',
 'Maria', '6933085089', 'Anastasios',
 'armed', 'A', 'DGZ4270');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Spanos', 'active',
 'Platonos 124', 'Patra', '1',
 'Ioanna', '6942558374', 'Michail',
 'armed', 'A', 'LAR7451');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Nikolaidis', 'active',
 'Venizelou 44', 'Athens', '1',
 'Maria', '6959428060', 'Thanasis',
 'armed', 'A', 'OLC0714');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Petridis', 'active',
 'Perikleous 199', 'Larisa', '1',
 'Maria', '6954394219', 'Ioannis',
 'armed', 'A', 'AXZ6447');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Panagiotou', 'active',
 'Vempo Sophias 109', 'Thessaloniki', '1',
 'Katerina', '6990908264', 'Michail',
 'armed', 'A', 'ZJY0177');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Papadopoulos', 'active',
 'Venizelou 78', 'Volos', '1',
 'Anna', '6965798449', 'Stelios',
 'armed', 'A', 'XSG7766');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Zafeiris', 'active',
 'Karaiskaki 54', 'Serres', '1',
 'Eirini', '6922441266', 'Alexandros',
 'armed', 'A', 'TNG8785');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Panagiotou', 'active',
 'Omirou 55', 'Chania', '1',
 'Vasiliki', '6994914429', 'Leonidas',
 'armed', 'A', 'UJV8228');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Spanos', 'active',
 'Omirou 196', 'Serres', '1',
 'Dimitra', '6995149514', 'Konstantinos',
 'armed', 'A', 'WPG8705');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Karaiskaki 20', 'Thessaloniki', '1',
 'Dimitra', '6982893586', 'Pavlos',
 'armed', 'A', 'RGV4601');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Kotsis', 'active',
 'Papandreou 26', 'Patra', '1',
 'Sofia', '6926074036', 'Sotirios',
 'armed', 'A', 'VUE4834');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Platonos 84', 'Volos', '1',
 'Eirini', '6987637523', 'Anastasios',
 'unarmed', 'A', 'TQC1885');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Spanos', 'active',
 'Omirou 30', 'Patra', '1',
 'Georgia', '6992320939', 'Michail',
 'armed', 'A', 'FPA8940');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Spanos', 'active',
 'Perikleous 35', 'Volos', '1',
 'Georgia', '6921847066', 'Vasileios',
 'armed', 'A', 'YLA9241');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Nikolaidis', 'active',
 'Perikleous 10', 'Larisa', '1',
 'Ioanna', '6962351713', 'Michail',
 'armed', 'A', 'SCQ5482');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Kotsis', 'active',
 'Solonos 82', 'Komotini', '1',
 'Dimitra', '6947608800', 'Stelios',
 'armed', 'A', 'IBV9539');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Petridis', 'active',
 'Omirou 99', 'Chania', '1',
 'Katerina', '6906816035', 'Georgios',
 'armed', 'A', 'XMC8153');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Papadopoulos', 'active',
 'Sokratous 91', 'Thessaloniki', '1',
 'Dimitra', '6905322193', 'Sotirios',
 'unarmed', 'A', 'FPD4681');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Solonos 179', 'Heraklion', '1',
 'Dimitra', '6969197070', 'Petros',
 'armed', 'A', 'PQM8557');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Karalis', 'active',
 'Venizelou 8', 'Patra', '1',
 'Georgia', '6918948322', 'Sotirios',
 'armed', 'A', 'ZLU3809');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Mantzouranis', 'active',
 'Karaiskaki 53', 'Patra', '1',
 'Vasiliki', '6966237882', 'Konstantinos',
 'unarmed', 'A', 'YRL9246');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Dedes', 'active',
 'Omirou 90', 'Heraklion', '1',
 'Katerina', '6952941689', 'Michail',
 'unarmed', 'A', 'BYW6606');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Karaiskaki 46', 'Thessaloniki', '1',
 'Eirini', '6965786891', 'Vasileios',
 'armed', 'A', 'JCJ9900');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Dedes', 'active',
 'Omirou 9', 'Larisa', '1',
 'Georgia', '6900390000', 'Anastasios',
 'armed', 'A', 'EWS3177');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Theodorakis', 'active',
 'Perikleous 132', 'Chania', '1',
 'Sofia', '6958158349', 'Pavlos',
 'armed', 'A', 'EMR5421');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Dedes', 'active',
 'Omirou 127', 'Athens', '1',
 'Anna', '6981585082', 'Christos',
 'armed', 'A', 'PXC8882');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Lazaridis', 'active',
 'Venizelou 113', 'Thessaloniki', '1',
 'Georgia', '6976819402', 'Manolis',
 'unarmed', 'A', 'FRH3213');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Christou', 'active',
 'Papandreou 60', 'Chania', '1',
 'Dimitra', '6918949365', 'Georgios',
 'armed', 'A', 'OJR8556');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Mantzouranis', 'active',
 'Platonos 83', 'Patra', '1',
 'Eirini', '6923983886', 'Ioannis',
 'armed', 'A', 'PWF9906');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Lazaridis', 'active',
 'Perikleous 53', 'Larisa', '1',
 'Sofia', '6967225810', 'Petros',
 'armed', 'A', 'ROZ2081');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Dedes', 'active',
 'Platonos 82', 'Chania', '1',
 'Sofia', '6923869198', 'Ioannis',
 'armed', 'A', 'HUL8364');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Theodorakis', 'active',
 'Perikleous 146', 'Larisa', '1',
 'Dimitra', '6972808115', 'Anastasios',
 'armed', 'A', 'NKV7751');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Zafeiris', 'active',
 'Omirou 190', 'Heraklion', '1',
 'Anna', '6937511961', 'Sotirios',
 'armed', 'A', 'DEK6214');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Georgiou', 'active',
 'Platonos 102', 'Athens', '1',
 'Georgia', '6922225093', 'Pavlos',
 'armed', 'A', 'TSM5746');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Alexopoulos', 'active',
 'Venizelou 117', 'Komotini', '1',
 'Katerina', '6950788020', 'Anastasios',
 'armed', 'A', 'DZN0039');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Petridis', 'active',
 'Sokratous 103', 'Larisa', '1',
 'Eleni', '6905270935', 'Manolis',
 'armed', 'A', 'UMH4317');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Panagiotou', 'active',
 'Platonos 144', 'Serres', '1',
 'Eleni', '6907029922', 'Christos',
 'armed', 'A', 'VRK9015');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Christou', 'active',
 'Platonos 76', 'Kavala', '1',
 'Anna', '6953707227', 'Michail',
 'armed', 'A', 'BRK4264');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Alexopoulos', 'active',
 'Karaiskaki 45', 'Komotini', '1',
 'Sofia', '6976594902', 'Ioannis',
 'armed', 'A', 'IQV1106');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Kotsis', 'active',
 'Platonos 14', 'Volos', '1',
 'Vasiliki', '6941745065', 'Theodoros',
 'armed', 'A', 'CGR0388');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Petridis', 'active',
 'Perikleous 41', 'Serres', '1',
 'Ioanna', '6995608133', 'Manolis',
 'armed', 'A', 'PGI1788');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Nikolaidis', 'active',
 'Sokratous 38', 'Larisa', '1',
 'Anna', '6965479864', 'Petros',
 'armed', 'A', 'ACE0810');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Panagiotou', 'active',
 'Karaiskaki 8', 'Serres', '1',
 'Maria', '6995685054', 'Konstantinos',
 'armed', 'A', 'ZAJ1903');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Georgiou', 'active',
 'Perikleous 25', 'Kavala', '1',
 'Eirini', '6922427985', 'Leonidas',
 'unarmed', 'A', 'YKB4115');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Zafeiris', 'active',
 'Solonos 112', 'Komotini', '1',
 'Sofia', '6911185272', 'Theodoros',
 'armed', 'A', 'DIY8915');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Spanos', 'active',
 'Venizelou 102', 'Patra', '1',
 'Ioanna', '6927912371', 'Ioannis',
 'armed', 'A', 'PKZ3516');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Lazaridis', 'active',
 'Solonos 65', 'Chania', '1',
 'Sofia', '6945162589', 'Pavlos',
 'armed', 'A', 'HFC3979');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Spanos', 'active',
 'Karaiskaki 104', 'Athens', '1',
 'Katerina', '6903808831', 'Stelios',
 'armed', 'A', 'EGB8216');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Papandreou 125', 'Volos', '1',
 'Anna', '6967631726', 'Georgios',
 'armed', 'A', 'DYL4306');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Georgiou', 'active',
 'Papandreou 49', 'Serres', '1',
 'Katerina', '6944088333', 'Georgios',
 'armed', 'A', 'RVK8423');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Venizelou 127', 'Kavala', '1',
 'Katerina', '6987373232', 'Ioannis',
 'armed', 'A', 'PEE8633');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Christou', 'active',
 'Solonos 8', 'Larisa', '1',
 'Eleni', '6929997851', 'Christos',
 'armed', 'A', 'FWN7637');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Petridis', 'active',
 'Platonos 6', 'Larisa', '1',
 'Katerina', '6931603170', 'Manolis',
 'unarmed', 'A', 'NCJ3836');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Georgiou', 'active',
 'Solonos 89', 'Kavala', '1',
 'Eirini', '6987281853', 'Alexandros',
 'armed', 'A', 'RPL7185');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Dedes', 'active',
 'Solonos 182', 'Athens', '1',
 'Dimitra', '6962444910', 'Konstantinos',
 'armed', 'A', 'WQK3444');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Dedes', 'active',
 'Sokratous 58', 'Athens', '1',
 'Ioanna', '6963751373', 'Sotirios',
 'armed', 'A', 'TSO0169');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Ioannou', 'active',
 'Sokratous 137', 'Thessaloniki', '1',
 'Dimitra', '6967187550', 'Konstantinos',
 'armed', 'A', 'AQN6494');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Sokratous 153', 'Patra', '1',
 'Dimitra', '6938210475', 'Anastasios',
 'armed', 'A', 'LYF6697');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Georgiou', 'active',
 'Vempo Sophias 185', 'Larisa', '1',
 'Eleni', '6901289214', 'Sotirios',
 'armed', 'A', 'ZRG0915');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Alexopoulos', 'active',
 'Perikleous 32', 'Serres', '1',
 'Vasiliki', '6988149831', 'Christos',
 'unarmed', 'A', 'DXX9050');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Georgiou', 'active',
 'Venizelou 140', 'Heraklion', '1',
 'Maria', '6963621272', 'Theodoros',
 'armed', 'A', 'OPS1484');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Perikleous 82', 'Thessaloniki', '1',
 'Vasiliki', '6971159503', 'Vasileios',
 'armed', 'A', 'QGZ0273');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Panagiotou', 'active',
 'Platonos 139', 'Chania', '1',
 'Vasiliki', '6954835998', 'Vasileios',
 'unarmed', 'A', 'QKZ0913');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Christou', 'active',
 'Vempo Sophias 117', 'Larisa', '1',
 'Maria', '6940777201', 'Alexandros',
 'armed', 'A', 'CGQ4081');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Alexopoulos', 'active',
 'Solonos 171', 'Volos', '1',
 'Katerina', '6948983711', 'Anastasios',
 'armed', 'A', 'PQU9155');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Georgiou', 'active',
 'Perikleous 150', 'Kavala', '1',
 'Eirini', '6973668848', 'Thanasis',
 'armed', 'A', 'JOG5862');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Alexopoulos', 'active',
 'Vempo Sophias 126', 'Komotini', '1',
 'Eleni', '6997673675', 'Ioannis',
 'armed', 'A', 'PMI9835');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Spanos', 'active',
 'Sokratous 110', 'Serres', '1',
 'Maria', '6980574218', 'Ioannis',
 'unarmed', 'A', 'TQK3008');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Papadopoulos', 'active',
 'Solonos 32', 'Komotini', '1',
 'Dimitra', '6932226229', 'Leonidas',
 'armed', 'A', 'BYW4898');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Georgiou', 'active',
 'Omirou 162', 'Volos', '1',
 'Vasiliki', '6951178168', 'Konstantinos',
 'armed', 'A', 'QAF7426');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Dedes', 'active',
 'Papandreou 41', 'Thessaloniki', '1',
 'Dimitra', '6949312479', 'Ioannis',
 'armed', 'A', 'HNA4752');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Athanasiadis', 'active',
 'Karaiskaki 47', 'Kavala', '1',
 'Katerina', '6923766381', 'Stelios',
 'unarmed', 'A', 'BLH5000');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Ioannou', 'active',
 'Sokratous 80', 'Serres', '1',
 'Sofia', '6939673426', 'Michail',
 'armed', 'A', 'BIS5029');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Mantzouranis', 'active',
 'Sokratous 187', 'Chania', '1',
 'Anna', '6969876153', 'Anastasios',
 'armed', 'A', 'VRW0985');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Zafeiris', 'active',
 'Solonos 173', 'Thessaloniki', '1',
 'Anna', '6900911722', 'Sotirios',
 'armed', 'A', 'AEZ5436');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Theodorakis', 'active',
 'Vempo Sophias 186', 'Patra', '1',
 'Sofia', '6990624624', 'Georgios',
 'armed', 'A', 'UKZ9256');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Lazaridis', 'active',
 'Venizelou 154', 'Larisa', '1',
 'Dimitra', '6968739200', 'Anastasios',
 'armed', 'A', 'ROI6187');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Georgiou', 'active',
 'Venizelou 18', 'Thessaloniki', '1',
 'Vasiliki', '6990436261', 'Konstantinos',
 'armed', 'A', 'DYS4212');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Spanos', 'active',
 'Platonos 54', 'Komotini', '1',
 'Ioanna', '6959767779', 'Thanasis',
 'armed', 'A', 'QEP4057');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Venizelou 11', 'Heraklion', '1',
 'Katerina', '6975524781', 'Konstantinos',
 'armed', 'A', 'TJU6450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Zafeiris', 'active',
 'Venizelou 20', 'Heraklion', '1',
 'Eirini', '6976554577', 'Michail',
 'armed', 'A', 'RHI0488');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Zafeiris', 'active',
 'Karaiskaki 136', 'Kavala', '1',
 'Katerina', '6969065029', 'Vasileios',
 'armed', 'A', 'LKT3735');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Mantzouranis', 'active',
 'Platonos 185', 'Volos', '1',
 'Eleni', '6912775622', 'Alexandros',
 'armed', 'A', 'PTM8767');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Alexopoulos', 'active',
 'Omirou 34', 'Patra', '1',
 'Eirini', '6979229054', 'Vasileios',
 'armed', 'A', 'JLK9724');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Georgiou', 'active',
 'Perikleous 35', 'Athens', '1',
 'Vasiliki', '6991893609', 'Petros',
 'armed', 'A', 'IFQ8746');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Mantzouranis', 'active',
 'Venizelou 155', 'Athens', '1',
 'Katerina', '6951629153', 'Michail',
 'armed', 'A', 'QJA0119');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Athanasiadis', 'active',
 'Perikleous 193', 'Larisa', '1',
 'Maria', '6971171521', 'Manolis',
 'armed', 'A', 'IIC3058');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Papadopoulos', 'active',
 'Sokratous 61', 'Serres', '1',
 'Maria', '6970253178', 'Theodoros',
 'armed', 'A', 'SNS9131');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Dedes', 'active',
 'Vempo Sophias 148', 'Komotini', '1',
 'Maria', '6928151864', 'Manolis',
 'armed', 'A', 'BAA8538');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Papadopoulos', 'active',
 'Omirou 189', 'Thessaloniki', '1',
 'Dimitra', '6919416257', 'Alexandros',
 'armed', 'A', 'NEW8500');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Nikolaidis', 'active',
 'Sokratous 133', 'Chania', '1',
 'Anna', '6917998652', 'Sotirios',
 'armed', 'A', 'JGQ0390');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Dedes', 'active',
 'Venizelou 127', 'Volos', '1',
 'Vasiliki', '6908596851', 'Konstantinos',
 'unarmed', 'A', 'PHQ2173');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Lazaridis', 'active',
 'Vempo Sophias 62', 'Serres', '1',
 'Maria', '6941495734', 'Michail',
 'armed', 'A', 'NLD7542');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Papandreou 52', 'Kavala', '1',
 'Georgia', '6946506218', 'Theodoros',
 'armed', 'A', 'QYX5542');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Omirou 197', 'Larisa', '1',
 'Vasiliki', '6920712474', 'Leonidas',
 'armed', 'A', 'UST1899');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Mantzouranis', 'active',
 'Sokratous 185', 'Athens', '1',
 'Sofia', '6971344319', 'Manolis',
 'armed', 'A', 'UGY4600');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Ioannou', 'active',
 'Karaiskaki 13', 'Serres', '1',
 'Eleni', '6925214914', 'Thanasis',
 'armed', 'A', 'EUF5463');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Alexopoulos', 'active',
 'Platonos 160', 'Athens', '1',
 'Ioanna', '6916206283', 'Alexandros',
 'armed', 'A', 'KNJ7334');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Ioannou', 'active',
 'Platonos 187', 'Patra', '1',
 'Sofia', '6966826577', 'Sotirios',
 'armed', 'A', 'TET7450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Christou', 'active',
 'Vempo Sophias 7', 'Serres', '1',
 'Eleni', '6904089010', 'Thanasis',
 'armed', 'A', 'YUZ0465');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Lazaridis', 'active',
 'Karaiskaki 54', 'Heraklion', '1',
 'Eleni', '6982925191', 'Petros',
 'armed', 'A', 'LNB5167');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Spanos', 'active',
 'Vempo Sophias 162', 'Komotini', '1',
 'Eirini', '6940996633', 'Petros',
 'armed', 'A', 'JVW6076');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Petridis', 'active',
 'Venizelou 59', 'Volos', '1',
 'Dimitra', '6985612850', 'Manolis',
 'armed', 'A', 'ICI1958');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Karalis', 'active',
 'Omirou 20', 'Serres', '1',
 'Katerina', '6914268834', 'Thanasis',
 'armed', 'A', 'RCO0273');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Kotsis', 'active',
 'Omirou 160', 'Thessaloniki', '1',
 'Eleni', '6944149749', 'Michail',
 'armed', 'A', 'VOP2831');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Omirou 142', 'Larisa', '1',
 'Georgia', '6972613883', 'Thanasis',
 'armed', 'A', 'ZSK6333');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Lazaridis', 'active',
 'Omirou 174', 'Serres', '1',
 'Eleni', '6999447986', 'Thanasis',
 'armed', 'A', 'OPR4955');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Theodorakis', 'active',
 'Papandreou 25', 'Larisa', '1',
 'Georgia', '6995740290', 'Georgios',
 'armed', 'A', 'UYC7836');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Dedes', 'active',
 'Omirou 39', 'Komotini', '1',
 'Anna', '6902495198', 'Sotirios',
 'armed', 'A', 'QQL2136');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Platonos 59', 'Serres', '1',
 'Dimitra', '6926378286', 'Michail',
 'armed', 'A', 'STT8350');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Petridis', 'active',
 'Solonos 129', 'Kavala', '1',
 'Katerina', '6930457323', 'Ioannis',
 'armed', 'A', 'AON9233');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Georgiou', 'active',
 'Vempo Sophias 31', 'Patra', '1',
 'Georgia', '6981169101', 'Theodoros',
 'armed', 'A', 'JCO6743');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Dedes', 'active',
 'Sokratous 34', 'Kavala', '1',
 'Ioanna', '6918410550', 'Thanasis',
 'armed', 'A', 'NNI8766');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Alexopoulos', 'active',
 'Vempo Sophias 163', 'Kavala', '1',
 'Ioanna', '6935647244', 'Ioannis',
 'armed', 'A', 'VEE6415');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Alexopoulos', 'active',
 'Omirou 88', 'Larisa', '1',
 'Ioanna', '6976780107', 'Pavlos',
 'armed', 'A', 'NAN3505');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Mantzouranis', 'active',
 'Platonos 26', 'Thessaloniki', '1',
 'Eleni', '6971562462', 'Anastasios',
 'armed', 'A', 'ADE6528');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Alexopoulos', 'active',
 'Perikleous 18', 'Chania', '1',
 'Katerina', '6963977839', 'Alexandros',
 'armed', 'A', 'KHZ2969');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Petridis', 'active',
 'Karaiskaki 141', 'Serres', '1',
 'Eirini', '6929308150', 'Theodoros',
 'armed', 'A', 'CDW5249');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Panagiotou', 'active',
 'Omirou 58', 'Chania', '1',
 'Dimitra', '6910475011', 'Leonidas',
 'armed', 'A', 'SNE7195');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Papadopoulos', 'active',
 'Papandreou 16', 'Komotini', '1',
 'Sofia', '6949793371', 'Stelios',
 'armed', 'A', 'ODC5697');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Athanasiadis', 'active',
 'Vempo Sophias 67', 'Komotini', '1',
 'Ioanna', '6913909993', 'Stelios',
 'armed', 'A', 'FQY4195');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Ioannou', 'active',
 'Papandreou 87', 'Chania', '1',
 'Georgia', '6956729966', 'Michail',
 'armed', 'A', 'HHB5751');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Nikolaidis', 'active',
 'Omirou 84', 'Athens', '1',
 'Maria', '6901435102', 'Michail',
 'armed', 'A', 'XUP8678');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Zafeiris', 'active',
 'Omirou 38', 'Komotini', '1',
 'Ioanna', '6962589107', 'Anastasios',
 'armed', 'A', 'WAO4746');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Alexopoulos', 'active',
 'Venizelou 190', 'Chania', '1',
 'Sofia', '6943272456', 'Ioannis',
 'unarmed', 'A', 'CGA9475');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Spanos', 'active',
 'Omirou 186', 'Serres', '1',
 'Vasiliki', '6972699747', 'Michail',
 'armed', 'A', 'BMH1283');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Sokratous 98', 'Patra', '1',
 'Anna', '6979301143', 'Anastasios',
 'armed', 'A', 'UGE1986');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Panagiotou', 'active',
 'Perikleous 61', 'Athens', '1',
 'Eirini', '6987331036', 'Pavlos',
 'unarmed', 'A', 'YQU8105');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Venizelou 85', 'Komotini', '1',
 'Eleni', '6929345489', 'Ioannis',
 'armed', 'A', 'FVL3783');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Lazaridis', 'active',
 'Karaiskaki 156', 'Heraklion', '1',
 'Eirini', '6941898011', 'Thanasis',
 'armed', 'A', 'SIN2546');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Petridis', 'active',
 'Vempo Sophias 148', 'Serres', '1',
 'Katerina', '6917222769', 'Pavlos',
 'armed', 'A', 'IGT0164');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Kotsis', 'active',
 'Venizelou 146', 'Komotini', '1',
 'Sofia', '6967486675', 'Alexandros',
 'armed', 'A', 'NWN3215');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Theodorakis', 'active',
 'Solonos 121', 'Heraklion', '1',
 'Anna', '6929790087', 'Pavlos',
 'armed', 'A', 'JXM7362');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Christou', 'active',
 'Vempo Sophias 2', 'Larisa', '1',
 'Dimitra', '6933162571', 'Manolis',
 'armed', 'A', 'BDV3782');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Petridis', 'active',
 'Sokratous 33', 'Komotini', '1',
 'Vasiliki', '6936819336', 'Sotirios',
 'armed', 'A', 'MTH0503');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Nikolaidis', 'active',
 'Papandreou 45', 'Athens', '1',
 'Eirini', '6999576821', 'Leonidas',
 'armed', 'A', 'FTZ7466');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Nikolaidis', 'active',
 'Platonos 119', 'Athens', '1',
 'Sofia', '6927810662', 'Konstantinos',
 'armed', 'A', 'IYK0107');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Spanos', 'active',
 'Platonos 158', 'Kavala', '1',
 'Anna', '6943140313', 'Michail',
 'unarmed', 'A', 'DXQ9501');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Perikleous 115', 'Heraklion', '1',
 'Georgia', '6965518129', 'Petros',
 'armed', 'A', 'PMX2999');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Kotsis', 'active',
 'Sokratous 2', 'Athens', '1',
 'Maria', '6932445506', 'Anastasios',
 'armed', 'A', 'MBW0750');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Solonos 166', 'Chania', '1',
 'Eirini', '6921652283', 'Christos',
 'armed', 'A', 'VMB2499');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Vempo Sophias 59', 'Heraklion', '1',
 'Eleni', '6914351693', 'Thanasis',
 'armed', 'A', 'HSK1823');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Lazaridis', 'active',
 'Vempo Sophias 190', 'Kavala', '1',
 'Maria', '6966286479', 'Vasileios',
 'unarmed', 'A', 'RXN6280');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Ioannou', 'active',
 'Sokratous 80', 'Larisa', '1',
 'Georgia', '6907415361', 'Sotirios',
 'armed', 'A', 'BDF4355');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Karalis', 'active',
 'Platonos 200', 'Heraklion', '1',
 'Vasiliki', '6959244971', 'Ioannis',
 'unarmed', 'A', 'ZVN8881');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Spanos', 'active',
 'Venizelou 11', 'Larisa', '1',
 'Maria', '6959020434', 'Georgios',
 'armed', 'A', 'BCG3311');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Alexopoulos', 'active',
 'Solonos 167', 'Serres', '1',
 'Ioanna', '6950458127', 'Theodoros',
 'armed', 'A', 'CKZ6119');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Georgiou', 'active',
 'Perikleous 154', 'Athens', '1',
 'Dimitra', '6909268434', 'Thanasis',
 'armed', 'A', 'IQH1594');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Christou', 'active',
 'Venizelou 153', 'Heraklion', '1',
 'Vasiliki', '6965903223', 'Ioannis',
 'unarmed', 'A', 'QYR9420');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Athanasiadis', 'active',
 'Vempo Sophias 16', 'Larisa', '1',
 'Maria', '6925191497', 'Leonidas',
 'armed', 'A', 'JRI2643');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Karalis', 'active',
 'Perikleous 142', 'Larisa', '1',
 'Anna', '6965406533', 'Christos',
 'armed', 'A', 'FUW3277');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Kotsis', 'active',
 'Sokratous 17', 'Thessaloniki', '1',
 'Eirini', '6968292336', 'Petros',
 'armed', 'A', 'LTO7137');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Kotsis', 'active',
 'Sokratous 79', 'Heraklion', '1',
 'Vasiliki', '6934656515', 'Ioannis',
 'unarmed', 'A', 'UFO9405');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Papandreou 66', 'Volos', '1',
 'Anna', '6935552308', 'Christos',
 'armed', 'A', 'LUU6733');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Georgiou', 'active',
 'Papandreou 122', 'Heraklion', '1',
 'Eirini', '6962488835', 'Petros',
 'armed', 'A', 'MIG7142');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Dedes', 'active',
 'Perikleous 193', 'Volos', '1',
 'Eirini', '6935942815', 'Anastasios',
 'armed', 'A', 'FSS6055');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Petridis', 'active',
 'Omirou 45', 'Athens', '1',
 'Ioanna', '6995280682', 'Christos',
 'armed', 'A', 'LZZ0675');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Platonos 28', 'Larisa', '1',
 'Eleni', '6970899556', 'Leonidas',
 'unarmed', 'A', 'UMD6867');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Kotsis', 'active',
 'Karaiskaki 137', 'Athens', '1',
 'Vasiliki', '6969215888', 'Ioannis',
 'armed', 'A', 'AUR2406');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Papadopoulos', 'active',
 'Venizelou 43', 'Patra', '1',
 'Ioanna', '6915499578', 'Vasileios',
 'unarmed', 'A', 'TOA5846');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Theodorakis', 'active',
 'Solonos 38', 'Larisa', '1',
 'Sofia', '6949698710', 'Alexandros',
 'armed', 'A', 'OVW8346');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Kotsis', 'active',
 'Platonos 192', 'Athens', '1',
 'Georgia', '6922846866', 'Christos',
 'unarmed', 'A', 'GUN4978');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Papadopoulos', 'active',
 'Solonos 79', 'Larisa', '1',
 'Georgia', '6975399605', 'Leonidas',
 'armed', 'A', 'AUB6284');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Perikleous 175', 'Thessaloniki', '1',
 'Dimitra', '6984228542', 'Petros',
 'armed', 'A', 'VII1323');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Ioannou', 'active',
 'Perikleous 115', 'Komotini', '1',
 'Georgia', '6932947278', 'Michail',
 'armed', 'A', 'UVT1503');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Alexopoulos', 'active',
 'Omirou 43', 'Heraklion', '1',
 'Maria', '6962685087', 'Konstantinos',
 'armed', 'A', 'TQR3934');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Panagiotou', 'active',
 'Platonos 141', 'Komotini', '1',
 'Eirini', '6993359908', 'Manolis',
 'armed', 'A', 'LLI3797');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Solonos 135', 'Komotini', '1',
 'Anna', '6902259834', 'Stelios',
 'armed', 'A', 'FIU3390');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Vempo Sophias 151', 'Serres', '1',
 'Anna', '6972297370', 'Stelios',
 'armed', 'A', 'ODL4348');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Mantzouranis', 'active',
 'Karaiskaki 157', 'Patra', '1',
 'Sofia', '6947495235', 'Pavlos',
 'armed', 'A', 'CCC3345');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Zafeiris', 'active',
 'Vempo Sophias 180', 'Volos', '1',
 'Katerina', '6991760875', 'Alexandros',
 'armed', 'A', 'CGM2550');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Sokratous 3', 'Heraklion', '1',
 'Katerina', '6933161403', 'Anastasios',
 'armed', 'A', 'LLG6524');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Zafeiris', 'active',
 'Sokratous 188', 'Heraklion', '1',
 'Ioanna', '6965798613', 'Christos',
 'armed', 'A', 'LUW3186');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Omirou 200', 'Patra', '1',
 'Katerina', '6975803307', 'Konstantinos',
 'armed', 'A', 'TIG2644');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Athanasiadis', 'active',
 'Karaiskaki 189', 'Volos', '1',
 'Vasiliki', '6929793270', 'Manolis',
 'armed', 'A', 'KGC1717');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Georgiou', 'active',
 'Sokratous 53', 'Volos', '1',
 'Georgia', '6910486049', 'Stelios',
 'armed', 'A', 'JNH3833');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Papadopoulos', 'active',
 'Karaiskaki 44', 'Chania', '1',
 'Dimitra', '6927288157', 'Pavlos',
 'unarmed', 'A', 'DJG9800');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Karalis', 'active',
 'Papandreou 73', 'Kavala', '1',
 'Eirini', '6938303749', 'Pavlos',
 'armed', 'A', 'ILM2121');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Theodorakis', 'active',
 'Perikleous 135', 'Chania', '1',
 'Ioanna', '6972131843', 'Thanasis',
 'armed', 'A', 'VOO1610');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Dedes', 'active',
 'Solonos 132', 'Kavala', '1',
 'Eirini', '6954242063', 'Leonidas',
 'unarmed', 'A', 'YDQ3180');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Athanasiadis', 'active',
 'Omirou 156', 'Kavala', '1',
 'Eleni', '6911716388', 'Manolis',
 'armed', 'A', 'GMZ8450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Athanasiadis', 'active',
 'Perikleous 82', 'Kavala', '1',
 'Sofia', '6981395961', 'Ioannis',
 'armed', 'A', 'EEK8027');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Panagiotou', 'active',
 'Papandreou 188', 'Athens', '1',
 'Georgia', '6969091361', 'Christos',
 'armed', 'A', 'GNF7755');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Spanos', 'active',
 'Perikleous 21', 'Kavala', '1',
 'Sofia', '6973022317', 'Leonidas',
 'armed', 'A', 'OHA2649');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Kotsis', 'active',
 'Perikleous 13', 'Kavala', '1',
 'Eleni', '6953864472', 'Manolis',
 'armed', 'A', 'CDL3727');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Athanasiadis', 'active',
 'Karaiskaki 35', 'Kavala', '1',
 'Georgia', '6988639896', 'Vasileios',
 'armed', 'A', 'VRD0641');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Panagiotou', 'active',
 'Vempo Sophias 86', 'Komotini', '1',
 'Georgia', '6911806837', 'Leonidas',
 'armed', 'A', 'QPR6078');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Petridis', 'active',
 'Sokratous 153', 'Athens', '1',
 'Katerina', '6925557595', 'Petros',
 'armed', 'A', 'LGC1226');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Spanos', 'active',
 'Vempo Sophias 163', 'Athens', '1',
 'Eirini', '6955177135', 'Theodoros',
 'armed', 'A', 'AVA6018');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Nikolaidis', 'active',
 'Vempo Sophias 81', 'Patra', '1',
 'Georgia', '6903019514', 'Vasileios',
 'armed', 'A', 'IAJ4957');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Mantzouranis', 'active',
 'Solonos 112', 'Kavala', '1',
 'Eleni', '6944334219', 'Leonidas',
 'unarmed', 'A', 'WGR3721');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Petridis', 'active',
 'Sokratous 132', 'Kavala', '1',
 'Eleni', '6919039089', 'Stelios',
 'armed', 'A', 'SUY9211');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Lazaridis', 'active',
 'Papandreou 148', 'Athens', '1',
 'Georgia', '6973701853', 'Stelios',
 'armed', 'A', 'UGQ3129');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Zafeiris', 'active',
 'Vempo Sophias 61', 'Volos', '1',
 'Eirini', '6975821174', 'Petros',
 'armed', 'A', 'UDQ7595');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Georgiou', 'active',
 'Venizelou 99', 'Komotini', '1',
 'Ioanna', '6979777629', 'Thanasis',
 'armed', 'A', 'HXB3590');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Lazaridis', 'active',
 'Platonos 139', 'Serres', '1',
 'Katerina', '6916303911', 'Vasileios',
 'armed', 'A', 'WPO1301');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Panagiotou', 'active',
 'Papandreou 81', 'Kavala', '1',
 'Eleni', '6936101134', 'Konstantinos',
 'armed', 'A', 'FKH4700');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Christou', 'active',
 'Perikleous 197', 'Serres', '1',
 'Sofia', '6979715813', 'Theodoros',
 'armed', 'A', 'LAY1760');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Athanasiadis', 'active',
 'Karaiskaki 165', 'Chania', '1',
 'Dimitra', '6924776058', 'Pavlos',
 'armed', 'A', 'NGM1984');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Zafeiris', 'active',
 'Karaiskaki 58', 'Volos', '1',
 'Katerina', '6945437603', 'Theodoros',
 'armed', 'A', 'YXW8843');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Georgiou', 'active',
 'Omirou 154', 'Kavala', '1',
 'Ioanna', '6945226510', 'Anastasios',
 'unarmed', 'A', 'SSK7808');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Christou', 'active',
 'Platonos 27', 'Thessaloniki', '1',
 'Dimitra', '6925217872', 'Stelios',
 'armed', 'A', 'XXA3176');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Mantzouranis', 'active',
 'Solonos 179', 'Athens', '1',
 'Anna', '6910365394', 'Konstantinos',
 'armed', 'A', 'HDL4151');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Dedes', 'active',
 'Karaiskaki 198', 'Patra', '1',
 'Anna', '6916110155', 'Michail',
 'armed', 'A', 'QSU1110');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Lazaridis', 'active',
 'Omirou 69', 'Thessaloniki', '1',
 'Katerina', '6932349310', 'Ioannis',
 'armed', 'A', 'YOZ0713');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Karalis', 'active',
 'Sokratous 9', 'Patra', '1',
 'Georgia', '6923275185', 'Vasileios',
 'armed', 'A', 'KOI8486');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Papandreou 158', 'Larisa', '1',
 'Katerina', '6948509425', 'Manolis',
 'armed', 'A', 'RTN5638');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Karalis', 'active',
 'Platonos 67', 'Kavala', '1',
 'Maria', '6939713068', 'Alexandros',
 'armed', 'A', 'QDJ8502');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Ioannou', 'active',
 'Karaiskaki 72', 'Serres', '1',
 'Eleni', '6948819612', 'Georgios',
 'armed', 'A', 'BIZ8210');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Ioannou', 'active',
 'Omirou 93', 'Serres', '1',
 'Ioanna', '6990569908', 'Leonidas',
 'armed', 'A', 'YHU2578');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Mantzouranis', 'active',
 'Venizelou 120', 'Volos', '1',
 'Maria', '6934968267', 'Thanasis',
 'armed', 'A', 'PAC9126');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Dedes', 'active',
 'Vempo Sophias 100', 'Athens', '1',
 'Dimitra', '6986040797', 'Manolis',
 'armed', 'A', 'EPH2153');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Athanasiadis', 'active',
 'Papandreou 77', 'Serres', '1',
 'Eirini', '6995802054', 'Sotirios',
 'unarmed', 'A', 'RNP6829');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Spanos', 'active',
 'Platonos 65', 'Athens', '1',
 'Maria', '6913031388', 'Manolis',
 'armed', 'A', 'RTF6449');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Ioannou', 'active',
 'Papandreou 29', 'Athens', '1',
 'Dimitra', '6966990059', 'Konstantinos',
 'armed', 'A', 'RQT3828');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Panagiotou', 'active',
 'Perikleous 128', 'Chania', '1',
 'Georgia', '6969776886', 'Konstantinos',
 'armed', 'A', 'SCY4355');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Kotsis', 'active',
 'Platonos 160', 'Heraklion', '1',
 'Sofia', '6952722001', 'Sotirios',
 'armed', 'A', 'JBP9222');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Karalis', 'active',
 'Platonos 43', 'Heraklion', '1',
 'Sofia', '6969490514', 'Petros',
 'unarmed', 'A', 'UOI2141');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Christou', 'active',
 'Karaiskaki 91', 'Heraklion', '1',
 'Ioanna', '6915747538', 'Alexandros',
 'armed', 'A', 'SOD6507');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Nikolaidis', 'active',
 'Vempo Sophias 87', 'Heraklion', '1',
 'Vasiliki', '6978951521', 'Konstantinos',
 'armed', 'A', 'NEB1819');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Zafeiris', 'active',
 'Vempo Sophias 137', 'Komotini', '1',
 'Katerina', '6929131066', 'Theodoros',
 'armed', 'A', 'PEU4488');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Georgiou', 'active',
 'Perikleous 19', 'Serres', '1',
 'Eirini', '6984570965', 'Stelios',
 'armed', 'A', 'LUS5706');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Solonos 172', 'Athens', '1',
 'Georgia', '6971915745', 'Sotirios',
 'armed', 'A', 'RXK0291');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Lazaridis', 'active',
 'Solonos 186', 'Komotini', '1',
 'Anna', '6900591256', 'Georgios',
 'armed', 'A', 'NAV4122');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Ioannou', 'active',
 'Perikleous 16', 'Larisa', '1',
 'Katerina', '6996147269', 'Sotirios',
 'armed', 'A', 'KWQ5446');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Ioannou', 'active',
 'Papandreou 172', 'Komotini', '1',
 'Ioanna', '6965472953', 'Theodoros',
 'armed', 'A', 'NYV3191');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Spanos', 'active',
 'Solonos 198', 'Serres', '1',
 'Dimitra', '6961813951', 'Alexandros',
 'armed', 'A', 'NDH7294');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Kotsis', 'active',
 'Sokratous 151', 'Serres', '1',
 'Dimitra', '6984352057', 'Sotirios',
 'armed', 'A', 'BUL4271');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Panagiotou', 'active',
 'Sokratous 10', 'Patra', '1',
 'Ioanna', '6938732116', 'Theodoros',
 'unarmed', 'A', 'AWT0894');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Vempo Sophias 118', 'Larisa', '1',
 'Maria', '6951736152', 'Vasileios',
 'armed', 'A', 'DDW4286');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Petridis', 'active',
 'Venizelou 127', 'Larisa', '1',
 'Sofia', '6964396007', 'Theodoros',
 'armed', 'A', 'WII8430');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Karalis', 'active',
 'Platonos 166', 'Heraklion', '1',
 'Ioanna', '6966147234', 'Petros',
 'armed', 'A', 'XXE6947');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Petridis', 'active',
 'Karaiskaki 74', 'Chania', '1',
 'Georgia', '6914899317', 'Manolis',
 'armed', 'A', 'XKX7699');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Theodorakis', 'active',
 'Platonos 19', 'Athens', '1',
 'Katerina', '6956814995', 'Alexandros',
 'armed', 'A', 'NXW9473');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Georgiou', 'active',
 'Solonos 185', 'Heraklion', '1',
 'Katerina', '6995330952', 'Anastasios',
 'armed', 'A', 'AMZ7666');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Karalis', 'active',
 'Solonos 46', 'Serres', '1',
 'Eirini', '6944883845', 'Konstantinos',
 'armed', 'A', 'NZY8260');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Athanasiadis', 'active',
 'Papandreou 174', 'Serres', '1',
 'Vasiliki', '6980116829', 'Michail',
 'armed', 'A', 'SRR2276');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Papadopoulos', 'active',
 'Platonos 1', 'Thessaloniki', '1',
 'Eirini', '6933032853', 'Theodoros',
 'armed', 'A', 'MAJ7132');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Papadopoulos', 'active',
 'Solonos 154', 'Serres', '1',
 'Eirini', '6937615215', 'Alexandros',
 'armed', 'A', 'GPK1601');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Kotsis', 'active',
 'Perikleous 90', 'Thessaloniki', '1',
 'Eirini', '6946318779', 'Ioannis',
 'armed', 'A', 'IRL1911');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Alexopoulos', 'active',
 'Solonos 177', 'Patra', '1',
 'Eirini', '6942163752', 'Stelios',
 'armed', 'A', 'BGD2046');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Lazaridis', 'active',
 'Platonos 77', 'Chania', '1',
 'Georgia', '6911881043', 'Georgios',
 'unarmed', 'A', 'SKX9093');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Nikos', 'Christou', 'active',
 'Papandreou 151', 'Kavala', '1',
 'Dimitra', '6987090415', 'Anastasios',
 'armed', 'A', 'FVG0315');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Petridis', 'active',
 'Omirou 17', 'Heraklion', '1',
 'Dimitra', '6914773999', 'Christos',
 'armed', 'A', 'JQA6710');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Christou', 'active',
 'Perikleous 1', 'Komotini', '1',
 'Eleni', '6979624721', 'Leonidas',
 'armed', 'A', 'XHN7450');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Petridis', 'active',
 'Omirou 134', 'Thessaloniki', '1',
 'Sofia', '6946548039', 'Thanasis',
 'armed', 'A', 'XIK5779');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Spanos', 'active',
 'Vempo Sophias 45', 'Athens', '1',
 'Anna', '6960422667', 'Konstantinos',
 'armed', 'A', 'WZY8384');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Lazaridis', 'active',
 'Solonos 191', 'Kavala', '1',
 'Vasiliki', '6980025671', 'Christos',
 'armed', 'A', 'YQQ7910');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Christou', 'active',
 'Omirou 12', 'Thessaloniki', '1',
 'Eirini', '6978591541', 'Petros',
 'armed', 'A', 'ZPV0312');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Christou', 'active',
 'Perikleous 31', 'Serres', '1',
 'Georgia', '6921363111', 'Christos',
 'armed', 'A', 'FDQ8598');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Dedes', 'active',
 'Omirou 117', 'Athens', '1',
 'Maria', '6927931250', 'Christos',
 'armed', 'A', 'PHA4788');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Theodorakis', 'active',
 'Venizelou 67', 'Larisa', '1',
 'Eleni', '6951947370', 'Sotirios',
 'unarmed', 'A', 'OKT9402');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Panagiotou', 'active',
 'Papandreou 99', 'Patra', '1',
 'Anna', '6988012569', 'Leonidas',
 'armed', 'A', 'JHM0806');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Platonos 159', 'Heraklion', '1',
 'Vasiliki', '6946040587', 'Konstantinos',
 'armed', 'A', 'KZQ5555');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Karalis', 'active',
 'Platonos 33', 'Serres', '1',
 'Anna', '6932924472', 'Georgios',
 'armed', 'A', 'DCB6392');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Panagiotou', 'active',
 'Platonos 51', 'Heraklion', '1',
 'Georgia', '6901002308', 'Petros',
 'armed', 'A', 'GUC2502');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Alexopoulos', 'active',
 'Solonos 44', 'Athens', '1',
 'Ioanna', '6922870947', 'Leonidas',
 'armed', 'A', 'KMO5854');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Lazaridis', 'active',
 'Vempo Sophias 173', 'Thessaloniki', '1',
 'Anna', '6986434442', 'Petros',
 'armed', 'A', 'YBV1594');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Karalis', 'active',
 'Platonos 160', 'Chania', '1',
 'Eirini', '6918781542', 'Ioannis',
 'armed', 'A', 'BFZ9991');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Kotsis', 'active',
 'Venizelou 15', 'Athens', '1',
 'Eirini', '6927278459', 'Michail',
 'armed', 'A', 'BUR4608');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Georgiou', 'active',
 'Karaiskaki 186', 'Larisa', '1',
 'Sofia', '6916568321', 'Pavlos',
 'armed', 'A', 'FRF0352');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Zafeiris', 'active',
 'Vempo Sophias 123', 'Serres', '1',
 'Anna', '6912633803', 'Vasileios',
 'unarmed', 'A', 'UZD4924');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Papadopoulos', 'active',
 'Omirou 69', 'Volos', '1',
 'Anna', '6903111625', 'Stelios',
 'armed', 'A', 'ZVL4053');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Mantzouranis', 'active',
 'Vempo Sophias 105', 'Larisa', '1',
 'Eleni', '6957045721', 'Anastasios',
 'unarmed', 'A', 'ATQ8421');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Ioannou', 'active',
 'Papandreou 35', 'Serres', '1',
 'Sofia', '6995816323', 'Pavlos',
 'armed', 'A', 'TSA0479');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Dedes', 'active',
 'Karaiskaki 162', 'Komotini', '1',
 'Maria', '6920737532', 'Petros',
 'armed', 'A', 'KLT4741');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Theodorakis', 'active',
 'Venizelou 103', 'Heraklion', '1',
 'Ioanna', '6987646719', 'Stelios',
 'armed', 'A', 'GTV6936');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Mantzouranis', 'active',
 'Omirou 26', 'Kavala', '1',
 'Dimitra', '6945455981', 'Petros',
 'armed', 'A', 'QCE6697');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Nikolaidis', 'active',
 'Solonos 42', 'Thessaloniki', '1',
 'Eirini', '6931947637', 'Vasileios',
 'armed', 'A', 'KIX1961');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Mantzouranis', 'active',
 'Karaiskaki 74', 'Larisa', '1',
 'Katerina', '6948194662', 'Anastasios',
 'armed', 'A', 'PRT7733');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Christou', 'active',
 'Sokratous 178', 'Athens', '1',
 'Anna', '6920940635', 'Manolis',
 'armed', 'A', 'LMK9937');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Leonidas', 'Georgiou', 'active',
 'Perikleous 158', 'Kavala', '1',
 'Maria', '6904804520', 'Leonidas',
 'armed', 'A', 'XMX3365');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Christou', 'active',
 'Venizelou 70', 'Serres', '1',
 'Dimitra', '6972666409', 'Georgios',
 'armed', 'A', 'ZEB8866');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Karaiskaki 25', 'Chania', '1',
 'Eleni', '6951526458', 'Stelios',
 'armed', 'A', 'ZQS1967');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Karalis', 'active',
 'Karaiskaki 193', 'Volos', '1',
 'Katerina', '6915857493', 'Petros',
 'armed', 'A', 'WIM9821');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Zafeiris', 'active',
 'Solonos 185', 'Chania', '1',
 'Sofia', '6986877568', 'Pavlos',
 'unarmed', 'A', 'TVP7040');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Nikolaidis', 'active',
 'Perikleous 36', 'Chania', '1',
 'Dimitra', '6922404925', 'Pavlos',
 'armed', 'A', 'OHZ3403');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Kotsis', 'active',
 'Papandreou 46', 'Heraklion', '1',
 'Eleni', '6918485590', 'Alexandros',
 'armed', 'A', 'RJX0022');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Petridis', 'active',
 'Sokratous 178', 'Volos', '1',
 'Eirini', '6965611937', 'Konstantinos',
 'armed', 'A', 'PWS8048');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Papadopoulos', 'active',
 'Platonos 73', 'Chania', '1',
 'Ioanna', '6988929331', 'Stelios',
 'armed', 'A', 'GAA5267');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Kostas', 'Georgiou', 'active',
 'Perikleous 66', 'Thessaloniki', '1',
 'Eleni', '6990881696', 'Georgios',
 'unarmed', 'A', 'UUI2367');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Karalis', 'active',
 'Vempo Sophias 96', 'Serres', '1',
 'Vasiliki', '6919503855', 'Vasileios',
 'unarmed', 'A', 'ZYD5551');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Petridis', 'active',
 'Karaiskaki 114', 'Thessaloniki', '1',
 'Katerina', '6951734577', 'Alexandros',
 'armed', 'A', 'DYN9024');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Georgiou', 'active',
 'Venizelou 200', 'Chania', '1',
 'Katerina', '6932805525', 'Manolis',
 'armed', 'A', 'ZGJ5852');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Ioannou', 'active',
 'Platonos 168', 'Heraklion', '1',
 'Katerina', '6927620092', 'Georgios',
 'armed', 'A', 'CSI1944');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Manolis', 'Spanos', 'active',
 'Karaiskaki 96', 'Heraklion', '1',
 'Katerina', '6960737023', 'Vasileios',
 'armed', 'A', 'QJN4469');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Dedes', 'active',
 'Omirou 21', 'Komotini', '1',
 'Maria', '6961759629', 'Leonidas',
 'armed', 'A', 'NVQ0691');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Lazaridis', 'active',
 'Papandreou 143', 'Komotini', '1',
 'Ioanna', '6929051068', 'Petros',
 'armed', 'A', 'MZF2921');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Petridis', 'active',
 'Karaiskaki 117', 'Serres', '1',
 'Dimitra', '6939897132', 'Alexandros',
 'armed', 'A', 'YTM5169');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Athanasiadis', 'active',
 'Platonos 200', 'Heraklion', '1',
 'Eirini', '6995770248', 'Petros',
 'armed', 'A', 'IEI2934');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Petridis', 'active',
 'Venizelou 79', 'Komotini', '1',
 'Dimitra', '6901294485', 'Thanasis',
 'armed', 'A', 'GNL7894');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Panagiotou', 'active',
 'Venizelou 141', 'Patra', '1',
 'Dimitra', '6994655678', 'Thanasis',
 'unarmed', 'A', 'DKR4720');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Ioannou', 'active',
 'Sokratous 62', 'Athens', '1',
 'Sofia', '6977702785', 'Christos',
 'unarmed', 'A', 'IUX6102');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Zafeiris', 'active',
 'Karaiskaki 25', 'Chania', '1',
 'Ioanna', '6960789528', 'Stelios',
 'armed', 'A', 'CSW2642');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Theodorakis', 'active',
 'Solonos 43', 'Komotini', '1',
 'Dimitra', '6932814142', 'Theodoros',
 'unarmed', 'A', 'JAY1208');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Panagiotou', 'active',
 'Sokratous 61', 'Chania', '1',
 'Sofia', '6998773590', 'Christos',
 'unarmed', 'A', 'MCN2177');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giorgos', 'Alexopoulos', 'active',
 'Papandreou 192', 'Kavala', '1',
 'Ioanna', '6911690469', 'Manolis',
 'armed', 'A', 'URY6156');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Alexandros', 'Petridis', 'active',
 'Papandreou 127', 'Chania', '1',
 'Eleni', '6948532393', 'Anastasios',
 'armed', 'A', 'YWC3429');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Dimitrios', 'Theodorakis', 'active',
 'Perikleous 144', 'Thessaloniki', '1',
 'Dimitra', '6960816346', 'Manolis',
 'armed', 'A', 'PFP2626');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Dedes', 'active',
 'Sokratous 19', 'Kavala', '1',
 'Georgia', '6939141321', 'Christos',
 'armed', 'A', 'UAC0642');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Antonis', 'Christou', 'active',
 'Platonos 48', 'Komotini', '1',
 'Maria', '6937568508', 'Petros',
 'armed', 'A', 'ZUZ4020');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Michalis', 'Mantzouranis', 'active',
 'Papandreou 129', 'Heraklion', '1',
 'Eleni', '6942135447', 'Alexandros',
 'armed', 'A', 'PQG7108');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Mantzouranis', 'active',
 'Sokratous 192', 'Thessaloniki', '1',
 'Dimitra', '6990992667', 'Anastasios',
 'armed', 'A', 'CQJ0542');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Dedes', 'active',
 'Papandreou 16', 'Kavala', '1',
 'Ioanna', '6993483657', 'Michail',
 'unarmed', 'A', 'GZO1697');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Alexopoulos', 'active',
 'Perikleous 75', 'Chania', '1',
 'Katerina', '6901878016', 'Theodoros',
 'armed', 'A', 'PBZ8941');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Zafeiris', 'active',
 'Solonos 190', 'Chania', '1',
 'Vasiliki', '6924502160', 'Theodoros',
 'armed', 'A', 'LXK7390');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Pavlos', 'Panagiotou', 'active',
 'Platonos 4', 'Volos', '1',
 'Eleni', '6931573414', 'Theodoros',
 'armed', 'A', 'XOK7619');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Theodorakis', 'active',
 'Perikleous 94', 'Serres', '1',
 'Eleni', '6955321162', 'Leonidas',
 'armed', 'A', 'BCK0206');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Athanasiadis', 'active',
 'Solonos 112', 'Patra', '1',
 'Eleni', '6924574640', 'Thanasis',
 'armed', 'A', 'MTU0559');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Zafeiris', 'active',
 'Perikleous 71', 'Athens', '1',
 'Vasiliki', '6990612963', 'Vasileios',
 'armed', 'A', 'YOA6537');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Christou', 'active',
 'Perikleous 56', 'Patra', '1',
 'Eirini', '6995614917', 'Manolis',
 'unarmed', 'A', 'BTE3063');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Spyros', 'Papadopoulos', 'active',
 'Sokratous 50', 'Volos', '1',
 'Vasiliki', '6948342586', 'Ioannis',
 'armed', 'A', 'BWY5648');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Karalis', 'active',
 'Sokratous 95', 'Chania', '1',
 'Eirini', '6929299294', 'Sotirios',
 'unarmed', 'A', 'PUR2772');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Sotiris', 'Papadopoulos', 'active',
 'Perikleous 58', 'Komotini', '1',
 'Maria', '6904785035', 'Leonidas',
 'armed', 'A', 'IDK2219');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Nikolaidis', 'active',
 'Sokratous 153', 'Patra', '1',
 'Eleni', '6982420342', 'Christos',
 'armed', 'A', 'PCK6139');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Theodoros', 'Theodorakis', 'active',
 'Solonos 186', 'Thessaloniki', '1',
 'Vasiliki', '6983347640', 'Vasileios',
 'armed', 'A', 'MEZ5357');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Karalis', 'active',
 'Solonos 45', 'Chania', '1',
 'Sofia', '6908937400', 'Michail',
 'armed', 'A', 'KSY8387');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Stelios', 'Petridis', 'active',
 'Platonos 58', 'Heraklion', '1',
 'Eleni', '6996650606', 'Christos',
 'unarmed', 'A', 'NUL4220');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Alexopoulos', 'active',
 'Vempo Sophias 121', 'Athens', '1',
 'Eleni', '6949324235', 'Anastasios',
 'armed', 'A', 'GTP4621');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Vasilis', 'Christou', 'active',
 'Omirou 142', 'Heraklion', '1',
 'Vasiliki', '6967627288', 'Leonidas',
 'unarmed', 'A', 'OOB6359');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Markos', 'Georgiou', 'active',
 'Papandreou 163', 'Larisa', '1',
 'Vasiliki', '6996149950', 'Georgios',
 'armed', 'A', 'MXT7682');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Giannis', 'Papadopoulos', 'active',
 'Perikleous 115', 'Volos', '1',
 'Georgia', '6913687660', 'Stelios',
 'armed', 'A', 'SRH4588');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Karalis', 'active',
 'Omirou 43', 'Chania', '1',
 'Katerina', '6948972064', 'Michail',
 'armed', 'A', 'CFX2036');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Christos', 'Ioannou', 'active',
 'Karaiskaki 22', 'Thessaloniki', '1',
 'Dimitra', '6957981774', 'Leonidas',
 'armed', 'A', 'IHF8007');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Theodorakis', 'active',
 'Solonos 113', 'Chania', '1',
 'Vasiliki', '6975510232', 'Georgios',
 'armed', 'A', 'YQC8615');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Petros', 'Georgiou', 'active',
 'Venizelou 21', 'Patra', '1',
 'Ioanna', '6983778711', 'Konstantinos',
 'armed', 'A', 'JIG3601');
INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES(false, false, 1, 'Thanasis', 'Karalis', 'active',
 'Platonos 126', 'Volos', '1',
 'Georgia', '6982348542', 'Sotirios',
 'armed', 'A', 'XTC6154');
 

INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV1', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV2', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV3', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV4', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV5', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV6', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV7', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV8', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV9', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV10', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV11', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV12', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV13', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV14', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV15', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV16', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV17', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV18', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV19', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV20', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV21', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV22', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV23', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV24', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV25', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV26', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV27', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV28', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV29', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV30', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV31', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV32', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV33', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV34', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV35', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV36', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV37', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV38', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV39', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV40', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV41', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV42', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV43', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV44', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV45', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV46', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV47', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV48', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV49', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV50', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV51', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV52', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV53', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV54', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV55', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV56', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV57', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV58', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV59', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV60', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV61', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV62', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV63', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV64', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV65', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV66', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV67', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV68', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV69', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV70', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV71', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV72', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV73', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV74', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV75', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV76', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV77', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV78', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV79', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV80', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV81', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV82', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV83', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV84', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV85', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV86', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV87', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV88', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV89', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV90', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV91', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV92', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV93', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV94', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV95', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV96', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV97', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV98', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV99', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV100', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV101', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV102', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV103', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV104', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV105', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV106', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV107', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV108', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV109', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV110', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV111', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV112', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV113', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV114', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV115', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV116', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV117', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV118', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV119', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV120', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV121', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV122', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV123', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV124', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV125', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV126', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV127', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV128', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV129', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV130', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV131', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV132', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV133', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV134', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV135', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV136', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV137', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV138', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV139', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV140', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV141', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV142', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV143', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV144', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV145', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV146', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV147', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV148', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV149', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV150', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV151', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV152', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV153', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV154', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV155', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV156', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV157', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV158', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV159', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV160', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV161', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV162', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV163', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV164', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV165', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV166', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV167', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV168', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV169', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV170', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV171', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV172', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV173', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV174', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV175', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV176', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV177', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV178', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV179', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV180', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV181', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV182', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV183', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV184', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV185', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV186', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV187', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV188', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV189', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV190', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV191', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV192', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV193', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV194', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV195', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV196', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV197', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV198', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV199', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV200', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV201', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV202', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV203', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV204', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV205', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV206', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV207', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV208', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV209', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV210', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV211', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV212', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV213', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV214', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV215', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV216', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV217', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV218', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV219', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV220', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV221', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV222', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV223', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV224', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV225', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV226', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV227', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV228', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV229', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV230', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV231', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV232', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV233', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV234', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV235', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV236', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV237', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV238', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV239', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV240', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV241', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV242', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV243', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV244', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV245', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV246', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV247', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV248', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV249', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV250', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV251', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV252', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV253', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV254', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV255', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV256', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV257', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV258', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV259', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV260', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV261', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV262', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV263', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV264', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV265', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV266', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV267', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV268', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV269', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV270', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV271', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV272', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV273', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV274', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV275', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV276', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV277', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV278', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV279', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV280', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV281', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV282', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV283', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV284', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV285', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV286', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV287', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV288', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV289', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV290', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV291', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV292', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV293', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Perimeter patrol', 'A', 'SERV294', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV295', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV296', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV297', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV298', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV299', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV300', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV301', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV302', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV303', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV304', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV305', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV306', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV307', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV308', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV309', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV310', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV311', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV312', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV313', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV314', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV315', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV316', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV317', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV318', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV319', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV320', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV321', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV322', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift B', 'A', 'SERV323', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV324', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV325', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV326', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV327', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV328', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV329', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Guard post shift A', 'A', 'SERV330', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV331', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV332', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV333', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV334', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Night watch', 'A', 'SERV335', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV336', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Equipment room duty', 'A', 'SERV337', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Gate monitoring', 'A', 'SERV338', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Communication room duty', 'A', 'SERV339', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'armed', 'Vehicle checkpoint', 'A', 'SERV340', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV341', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV342', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV343', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV344', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV345', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV346', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV347', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV348', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV349', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV350', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV351', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV352', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV353', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV354', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV355', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV356', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV357', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV358', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV359', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV360', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV361', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV362', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV363', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV364', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV365', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV366', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV367', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV368', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV369', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV370', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV371', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV372', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV373', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV374', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV375', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV376', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV377', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV378', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV379', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV380', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV381', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV382', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV383', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV384', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV385', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV386', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV387', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV388', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV389', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV390', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV391', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV392', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV393', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV394', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV395', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV396', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV397', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV398', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV399', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV400', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV401', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV402', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV403', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV404', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV405', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV406', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV407', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV408', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV409', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV410', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV411', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV412', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV413', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV414', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV415', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV416', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV417', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV418', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV419', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV420', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV421', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV422', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV423', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV424', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV425', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV426', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV427', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV428', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV429', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV430', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV431', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV432', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV433', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV434', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV435', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV436', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV437', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV438', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV439', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV440', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV441', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV442', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV443', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV444', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV445', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV446', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV447', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV448', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV449', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV450', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV451', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV452', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV453', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV454', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV455', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV456', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV457', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV458', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV459', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV460', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV461', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV462', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV463', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV464', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV465', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV466', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV467', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV468', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift A', 'A', 'SERV469', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV470', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV471', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV472', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV473', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV474', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV475', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV476', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV477', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV478', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV479', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV480', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Guard post shift B', 'A', 'SERV481', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV482', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV483', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV484', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV485', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV486', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV487', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV488', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV489', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV490', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV491', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV492', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Perimeter patrol', 'A', 'SERV493', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Gate monitoring', 'A', 'SERV494', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV495', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV496', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Communication room duty', 'A', 'SERV497', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Equipment room duty', 'A', 'SERV498', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Vehicle checkpoint', 'A', 'SERV499', '');
INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES(false, 1, 'unarmed', 'Night watch', 'A', 'SERV500', '');

