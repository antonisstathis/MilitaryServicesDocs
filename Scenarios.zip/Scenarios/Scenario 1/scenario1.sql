INSERT INTO ms.soldiers
(discharged, is_personnel, unit_id, "name", surname, active, address, city, company,
 matronymic, mobile_phone, patronymic, situation, sold_group, soldier_registration_number)
VALUES
(false, false, 1, 'Kostas', 'Spanos', 'active', 'Vempo Sophias 9', 'Larisa', '1',
 'Eleni', '6937810872', 'Christos', 'armed', 'A', 'AWL1136'),

(false, false, 1, 'Pavlos', 'Mantzouranis', 'active', 'Solonos 59', 'Larisa', '1',
 'Eirini', '6934745193', 'Michail', 'armed', 'A', 'OWO8792'),

(false, false, 1, 'Pavlos', 'Papadopoulos', 'active', 'Solonos 41', 'Heraklion', '1',
 'Anna', '6975642081', 'Christos', 'armed', 'A', 'XHI6489'),

(false, false, 1, 'Leonidas', 'Kotsis', 'active', 'Sokratous 86', 'Komotini', '1',
 'Maria', '6913621258', 'Konstantinos', 'armed', 'A', 'QIE4205'),

(false, false, 1, 'Pavlos', 'Dedes', 'active', 'Vempo Sophias 153', 'Serres', '1',
 'Anna', '6954161653', 'Michail', 'armed', 'A', 'ESF4604'),

(false, false, 1, 'Thanasis', 'Panagiotou', 'active', 'Vempo Sophias 193', 'Larisa', '1',
 'Georgia', '6993751427', 'Ioannis', 'unarmed', 'A', 'HUX4851'),

(false, false, 1, 'Thanasis', 'Dedes', 'active', 'Papandreou 182', 'Athens', '1',
 'Ioanna', '6956886056', 'Alexandros', 'unarmed', 'A', 'YIW5786'),

(false, false, 1, 'Michalis', 'Theodorakis', 'active', 'Solonos 17', 'Kavala', '1',
 'Georgia', '6941117862', 'Pavlos', 'unarmed', 'A', 'AUB6076'),

(false, false, 1, 'Theodoros', 'Lazaridis', 'active', 'Sokratous 179', 'Heraklion', '1',
 'Ioanna', '6915319492', 'Michail', 'unarmed', 'A', 'WFL9917'),

(false, false, 1, 'Kostas', 'Spanos', 'active', 'Vempo Sophias 105', 'Athens', '1',
 'Sofia', '6961461152', 'Anastasios', 'armed', 'A', 'TRG9993'),

(false, false, 1, 'Kostas', 'Panagiotou', 'active', 'Solonos 132', 'Volos', '1',
 'Eleni', '6981544734', 'Alexandros', 'unarmed', 'A', 'KDW9165'),

(false, false, 1, 'Spyros', 'Ioannou', 'active', 'Sokratous 36', 'Larisa', '1',
 'Vasiliki', '6975936093', 'Theodoros', 'armed', 'A', 'GGC2139'),

(false, false, 1, 'Giannis', 'Christou', 'active', 'Vempo Sophias 36', 'Serres', '1',
 'Ioanna', '6982917231', 'Vasileios', 'armed', 'A', 'FVM8537'),

(false, false, 1, 'Christos', 'Dedes', 'active', 'Karaiskaki 58', 'Larisa', '1',
 'Sofia', '6956288882', 'Thanasis', 'armed', 'A', 'RPF9582'),

(false, false, 1, 'Thanasis', 'Georgiou', 'active', 'Sokratous 164', 'Larisa', '1',
 'Vasiliki', '6946503650', 'Anastasios', 'armed', 'A', 'VUW7931'),

(false, false, 1, 'Sotiris', 'Georgiou', 'active', 'Venizelou 181', 'Komotini', '1',
 'Eirini', '6951307663', 'Thanasis', 'unarmed', 'A', 'HMB9691');


INSERT INTO ms.ser_of_unit
(is_personnel, unit_id, armed, description, ser_group, ser_name, shift)
VALUES
(false, 1, 'armed',   'Guard post shift A',          'A', 'SERV1', ''),
(false, 1, 'armed',   'Guard post shift A',          'A', 'SERV2', ''),
(false, 1, 'armed',   'Gate monitoring',             'A', 'SERV3', ''),
(false, 1, 'armed',   'Communication room duty',     'A', 'SERV4', ''),
(false, 1, 'armed',   'Gate monitoring',             'A', 'SERV5', ''),
(false, 1, 'armed',   'Guard post shift A',          'A', 'SERV6', ''),
(false, 1, 'armed',   'Vehicle checkpoint',          'A', 'SERV7', ''),
(false, 1, 'unarmed', 'Communication room duty',     'A', 'SERV9', ''),
(false, 1, 'unarmed', 'Night watch',                 'A', 'SERV10', ''),
(false, 1, 'unarmed', 'Perimeter patrol',            'A', 'SERV11', ''),
(false, 1, 'unarmed', 'Guard post shift A',          'A', 'SERV12', '');
